package com.kasamates.app.core.network

import com.kasamates.app.core.data.TokenStore
import com.kasamates.app.core.network.dto.TokenResponse
import kotlinx.coroutines.runBlocking
import okhttp3.Authenticator
import okhttp3.Interceptor
import okhttp3.Request
import okhttp3.Response
import okhttp3.Route

/** Attaches the bearer token to every outgoing request when present. */
class AuthInterceptor(private val tokens: TokenStore) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val token = tokens.accessToken
        val request = chain.request()
        val authed = if (!token.isNullOrBlank() && request.header("Authorization") == null) {
            request.newBuilder().header("Authorization", "Bearer $token").build()
        } else request
        return chain.proceed(authed)
    }
}

/**
 * On a 401, exchanges the refresh token for a fresh access token exactly once
 * and replays the original request. Uses a bare client (no authenticator) to
 * avoid infinite loops.
 */
class TokenAuthenticator(
    private val tokens: TokenStore,
    private val doRefresh: suspend (String) -> TokenResponse,
) : Authenticator {

    override fun authenticate(route: Route?, response: Response): Request? {
        if (responseCount(response) >= 2) return null          // already retried
        val refresh = tokens.refreshToken ?: return null
        val fresh = try {
            runBlocking { doRefresh(refresh) }
        } catch (_: Throwable) {
            null
        } ?: return null

        tokens.saveTokens(fresh)
        return response.request.newBuilder()
            .header("Authorization", "Bearer ${fresh.access_token}")
            .build()
    }

    private fun responseCount(response: Response): Int {
        var r: Response? = response; var c = 1
        while (r?.priorResponse != null) { c++; r = r.priorResponse }
        return c
    }
}
