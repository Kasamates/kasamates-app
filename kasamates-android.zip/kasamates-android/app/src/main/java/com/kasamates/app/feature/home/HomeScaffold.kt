package com.kasamates.app.feature.home

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kasamates.app.feature.browse.BrowseListScreen
import com.kasamates.app.feature.browse.DiscoverScreen
import com.kasamates.app.feature.matches.ConversationsScreen
import com.kasamates.app.feature.profile.ProfileScreen
import com.kasamates.app.ui.common.Eyebrow
import com.kasamates.app.ui.common.PrimaryButton
import com.kasamates.app.ui.theme.Cream
import com.kasamates.app.ui.theme.CreamHi
import com.kasamates.app.ui.theme.CreamSurface
import com.kasamates.app.ui.theme.GoldBadge
import com.kasamates.app.ui.theme.GreenPrimary
import com.kasamates.app.ui.theme.Ink
import com.kasamates.app.ui.theme.InkSoft
import com.kasamates.app.ui.theme.Line
import com.kasamates.app.ui.theme.Muted

/** Bottom-nav destinations. Discover + Browse intentionally share one BrowseViewModel,
 *  because every tab here lives under the same "home" nav entry (one ViewModelStoreOwner). */
private enum class HomeTab(val label: String, val icon: ImageVector) {
    Discover("Discover", Icons.Filled.Home),
    Browse("Browse", Icons.Filled.Search),
    Matches("Matches", Icons.Filled.Favorite),
    Activity("Activity", Icons.Filled.Notifications),
    Profile("Profile", Icons.Filled.Person),
}

@Composable
fun HomeScaffold(
    onOpenChat: (Int, String) -> Unit,
    onEditProfile: () -> Unit,
    onSignOut: () -> Unit,
) {
    var tab by rememberSaveable { mutableStateOf(HomeTab.Discover) }

    Scaffold(
        containerColor = Cream,
        bottomBar = {
            NavigationBar(containerColor = CreamSurface, tonalElevation = 0.dp) {
                HomeTab.entries.forEach { t ->
                    NavigationBarItem(
                        selected = tab == t,
                        onClick = { tab = t },
                        icon = { Icon(t.icon, contentDescription = t.label, modifier = Modifier.size(22.dp)) },
                        label = { Text(t.label, fontSize = 11.sp) },
                        alwaysShowLabel = true,
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = GreenPrimary,
                            selectedTextColor = GreenPrimary,
                            indicatorColor = CreamHi,
                            unselectedIconColor = Muted,
                            unselectedTextColor = Muted,
                        ),
                    )
                }
            }
        },
    ) { padding ->
        Box(
            Modifier
                .fillMaxSize()
                .padding(padding),
        ) {
            when (tab) {
                HomeTab.Discover -> DiscoverScreen()
                HomeTab.Browse -> BrowseListScreen()
                HomeTab.Matches -> ConversationsScreen(onOpenChat = onOpenChat)
                HomeTab.Activity -> ActivityScreen()
                HomeTab.Profile -> ProfileScreen(onEditProfile = onEditProfile, onSignOut = onSignOut)
            }
        }
    }
}

/**
 * The skeleton showed an activity feed gated behind a premium upsell, but the backend
 * exposes no activity/feed endpoint — so rather than fabricate data we present an honest
 * premium screen describing the real free-tier limit (5 messages) and what Plus unlocks.
 * Billing isn't wired, so the CTA is intentionally inert.
 */
@Composable
private fun ActivityScreen() {
    Column(
        Modifier
            .fillMaxSize()
            .background(Cream)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp),
    ) {
        Spacer(Modifier.height(20.dp))
        Text(
            "Activity",
            style = MaterialTheme.typography.headlineMedium,
            color = Ink,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Likes, visits and who's into you.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkSoft,
        )

        Spacer(Modifier.height(20.dp))
        PremiumCard()

        Spacer(Modifier.height(24.dp))
        Text(
            "Recent activity",
            style = MaterialTheme.typography.titleMedium,
            color = Ink,
            fontWeight = FontWeight.SemiBold,
        )
        Spacer(Modifier.height(12.dp))
        EmptyActivity()
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun PremiumCard() {
    Column(
        Modifier
            .fillMaxWidth()
            .background(GreenPrimary, RoundedCornerShape(24.dp))
            .padding(22.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .background(GoldBadge.copy(alpha = 0.18f), CircleShape),
                contentAlignment = Alignment.Center,
            ) { Icon(Icons.Filled.Star, contentDescription = null, tint = GoldBadge, modifier = Modifier.size(22.dp)) }
            Spacer(Modifier.width(12.dp))
            Column {
                Eyebrow("KASA PLUS", color = GoldBadge)
                Text(
                    "Move in faster",
                    style = MaterialTheme.typography.titleLarge,
                    color = Cream,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        Spacer(Modifier.height(16.dp))
        Benefit("See everyone who liked you")
        Benefit("Unlimited messages — free accounts get 5")
        Benefit("Priority placement in discovery")
        Benefit("AI compatibility breakdowns on every match")

        Spacer(Modifier.height(20.dp))
        PrimaryButton(
            text = "Upgrade coming soon",
            onClick = { },
            enabled = false,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "In-app purchases aren't enabled in this build.",
            style = MaterialTheme.typography.bodySmall,
            color = Cream.copy(alpha = 0.65f),
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth(),
        )
    }
}

@Composable
private fun Benefit(text: String) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Filled.Check, contentDescription = null, tint = GoldBadge, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(10.dp))
        Text(text, style = MaterialTheme.typography.bodyMedium, color = Cream.copy(alpha = 0.92f))
    }
}

@Composable
private fun EmptyActivity() {
    Column(
        Modifier
            .fillMaxWidth()
            .background(CreamSurface, RoundedCornerShape(20.dp))
            .border(1.dp, Line, RoundedCornerShape(20.dp))
            .padding(vertical = 36.dp, horizontal = 20.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Icon(Icons.Filled.Notifications, contentDescription = null, tint = Muted, modifier = Modifier.size(34.dp))
        Spacer(Modifier.height(12.dp))
        Text(
            "No activity yet",
            style = MaterialTheme.typography.titleMedium,
            color = Ink,
        )
        Spacer(Modifier.height(4.dp))
        Text(
            "Keep swiping in Discover — likes and visits will show up here.",
            style = MaterialTheme.typography.bodyMedium,
            color = InkSoft,
            textAlign = TextAlign.Center,
        )
    }
}
