package com.kasamates.app.feature.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*

@Composable
fun AuthScreen(onAuthed: (needsOtp: Boolean) -> Unit) {
    val vm = kasaViewModel<AuthViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()

    var isRegister by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Cream)
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(72.dp))
        Text(
            "KASA",
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 52.sp,
            letterSpacing = 8.sp,
            color = GreenPrimary,
        )
        Spacer(Modifier.height(8.dp))
        Text(
            "Find your housemate, not a broker.",
            style = MaterialTheme.typography.bodyLarge,
            color = InkSoft,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(40.dp))

        Eyebrow(if (isRegister) "Create account" else "Welcome back")
        Spacer(Modifier.height(16.dp))

        if (isRegister) {
            KasaField(name, { name = it }, "Full name")
            Spacer(Modifier.height(12.dp))
        }
        KasaField(email, { email = it }, "Email", keyboardType = KeyboardType.Email)
        Spacer(Modifier.height(12.dp))
        if (isRegister) {
            KasaField(phone, { phone = it }, "Phone (optional)", keyboardType = KeyboardType.Phone)
            Spacer(Modifier.height(12.dp))
        }
        KasaField(password, { password = it }, "Password", isPassword = true)

        Spacer(Modifier.height(12.dp))
        ErrorBanner(ui.error)
        Spacer(Modifier.height(8.dp))

        PrimaryButton(
            text = if (isRegister) "Create account" else "Log in",
            loading = ui.loading,
            onClick = {
                if (isRegister) vm.register(name, email, password, phone) { onAuthed(true) }
                else vm.login(email, password) { needsOtp -> onAuthed(needsOtp) }
            },
        )

        Spacer(Modifier.height(16.dp))
        DividerWithLabel("or")
        Spacer(Modifier.height(16.dp))

        // Google sign-in shown for design parity; no backend endpoint exists yet.
        OutlinedButton(
            onClick = {},
            enabled = false,
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, Line),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
            contentPadding = PaddingValues(vertical = 16.dp),
            modifier = Modifier.fillMaxWidth().heightIn(min = 54.dp),
        ) { Text("Continue with Google", fontSize = 16.sp) }
        Text(
            "Google sign-in is coming soon.",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
            modifier = Modifier.padding(top = 6.dp),
        )

        Spacer(Modifier.height(24.dp))
        TextButton(onClick = { isRegister = !isRegister; vm.clearError() }) {
            Text(
                if (isRegister) "Already have an account? Log in"
                else "New here? Create an account",
                color = GreenAccent,
                fontWeight = FontWeight.Medium,
            )
        }
        Spacer(Modifier.height(40.dp))
    }
}

@Composable
private fun DividerWithLabel(label: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
        HorizontalDivider(modifier = Modifier.weight(1f), color = Line)
        Text(
            label,
            style = MaterialTheme.typography.labelMedium,
            color = Muted,
            modifier = Modifier.padding(horizontal = 12.dp),
        )
        HorizontalDivider(modifier = Modifier.weight(1f), color = Line)
    }
}
