package com.kasamates.app.feature.browse

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.core.network.dto.MatchCard
import com.kasamates.app.ui.common.FlowRowSimple
import com.kasamates.app.ui.common.KasaChip
import com.kasamates.app.ui.theme.*

@Composable
fun BrowseListScreen() {
    val vm = kasaViewModel<BrowseViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val liked = remember { mutableStateMapOf<Int, Boolean>() }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("Browse", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink)
                Text("Everyone looking right now", style = MaterialTheme.typography.bodySmall, color = InkSoft)
            }
            Spacer(Modifier.weight(1f))
            ui.cards.size.takeIf { it > 0 }?.let {
                Text("$it people", style = MaterialTheme.typography.labelMedium, color = Muted)
            }
        }

        when {
            ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = GreenPrimary) }
            ui.cards.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Text("No one to show yet.", color = InkSoft)
            }
            else -> LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                modifier = Modifier.fillMaxSize(),
            ) {
                items(ui.cards, key = { it.user_id.toString() + it.source }) { card ->
                    GridCard(card, vm.absUrl, liked[card.user_id] == true) {
                        liked[card.user_id] = true
                        vm.interactFromList(card, "like")
                    }
                }
            }
        }
    }
}

@Composable
private fun GridCard(
    card: MatchCard,
    absUrl: (String?) -> String?,
    isLiked: Boolean,
    onLike: () -> Unit,
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = CreamSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        shadowElevation = 2.dp,
    ) {
        Column {
            Box(Modifier.fillMaxWidth().height(150.dp)) {
                val photo = absUrl(card.profile_photo_url)
                if (photo != null) {
                    AsyncImage(model = photo, contentDescription = card.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                } else {
                    Box(
                        Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(GreenAccent, GreenDeep))),
                        contentAlignment = Alignment.Center,
                    ) { Text(card.name?.take(1)?.uppercase() ?: "?", color = Cream, fontSize = 40.sp, fontFamily = FontFamily.Serif) }
                }
                Surface(
                    color = GreenPrimary,
                    shape = RoundedCornerShape(50),
                    modifier = Modifier.align(Alignment.TopStart).padding(8.dp),
                ) {
                    Text("${card.compatibility_score}%", color = Cream, fontWeight = FontWeight.Bold, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                }
            }
            Column(Modifier.padding(12.dp)) {
                Text(
                    buildString { append(card.name ?: "Someone"); card.age?.let { append(", $it") } },
                    fontWeight = FontWeight.Bold, color = Ink, fontSize = 15.sp, maxLines = 1,
                )
                card.profile?.location?.let { Text(it, style = MaterialTheme.typography.labelMedium, color = InkSoft, maxLines = 1) }
                card.profile?.let {
                    if (it.budget_min != null && it.budget_max != null) {
                        Text("₹${it.budget_min}–${it.budget_max}", style = MaterialTheme.typography.labelMedium, color = GreenAccent, maxLines = 1)
                    }
                }
                Spacer(Modifier.height(8.dp))
                if (isLiked) {
                    Surface(color = LikeGreen.copy(alpha = 0.12f), shape = RoundedCornerShape(50), modifier = Modifier.fillMaxWidth()) {
                        Text("♥ Liked", color = LikeGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp, modifier = Modifier.padding(vertical = 7.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                } else {
                    Surface(
                        color = CreamHi,
                        shape = RoundedCornerShape(50),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
                        onClick = onLike,
                        modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(50)),
                    ) {
                        Text("♥ Like", color = GreenAccent, fontWeight = FontWeight.Medium, fontSize = 13.sp, modifier = Modifier.padding(vertical = 7.dp).fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                    }
                }
            }
        }
    }
}
