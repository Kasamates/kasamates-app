package com.kasamates.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.ui.Modifier
import com.kasamates.app.ui.nav.KasaNavHost
import com.kasamates.app.ui.theme.Cream
import com.kasamates.app.ui.theme.KasamatesTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        setContent {
            KasamatesTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = Cream) {
                    KasaNavHost()
                }
            }
        }
    }
}
