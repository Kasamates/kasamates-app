package com.kasamates.app.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.core.network.dto.ProfileOut
import com.kasamates.app.core.network.dto.UserOut
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*

@Composable
fun ProfileScreen(onEditProfile: () -> Unit, onSignOut: () -> Unit) {
    val vm = kasaViewModel<ProfileViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.load() }

    when {
        ui.loading -> FullScreenLoader()
        ui.user == null -> Box(Modifier.fillMaxSize().background(Cream), Alignment.Center) {
            Text(ui.error ?: "Profile unavailable", color = InkSoft)
        }
        else -> ProfileContent(ui.user!!, ui.profile, vm.absUrl, onEditProfile) { vm.signOut(onSignOut) }
    }
}

@Composable
private fun ProfileContent(
    user: UserOut,
    profile: ProfileOut?,
    absUrl: (String?) -> String?,
    onEdit: () -> Unit,
    onSignOut: () -> Unit,
) {
    Column(
        Modifier.fillMaxSize().background(Cream).verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(24.dp))
        Surface(shape = CircleShape, color = GreenAccent, modifier = Modifier.size(108.dp).clip(CircleShape)) {
            val photo = absUrl(user.profile_photo_url)
            if (photo != null) {
                AsyncImage(model = photo, contentDescription = user.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
            } else {
                Box(contentAlignment = Alignment.Center) {
                    Text(user.name?.take(1)?.uppercase() ?: "?", color = Cream, fontSize = 44.sp, fontFamily = FontFamily.Serif)
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        Text(
            buildString { append(user.name ?: "You"); user.age?.let { append(", $it") } },
            fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Ink,
        )
        profile?.location?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = InkSoft) }

        Spacer(Modifier.height(12.dp))
        FlowRowSimpleCentered {
            if (user.is_email_verified) VerifiedPill("Email")
            if (user.is_phone_verified) VerifiedPill("Phone")
            if (user.is_verified_badge) VerifiedPill("Verified")
            if (user.plan != "free") VerifiedPill(user.plan.replaceFirstChar { it.uppercase() })
        }

        // Compatibility fingerprint
        Spacer(Modifier.height(20.dp))
        SectionCard {
            Eyebrow("Compatibility fingerprint")
            Spacer(Modifier.height(4.dp))
            Text("How you live, at a glance", style = MaterialTheme.typography.titleMedium, color = Ink)
            FingerprintRadar(
                axes = fingerprintAxes(
                    sleepTime = profile?.sleep_time,
                    foodPref = profile?.food_pref,
                    noise = profile?.noise_tolerance,
                    cleanliness = profile?.cleanliness_level,
                    social = profile?.social_energy,
                    guestFrequency = profile?.guest_frequency,
                ),
                modifier = Modifier.fillMaxWidth().height(260.dp),
            )
            FlowRowSimpleCentered {
                listOf("Sleep", "Diet", "Noise", "Clean", "Social", "Guests").forEach {
                    Text("• $it", style = MaterialTheme.typography.labelSmall, color = Muted, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
        }

        // Bio
        profile?.bio?.takeIf { it.isNotBlank() }?.let { bio ->
            Spacer(Modifier.height(16.dp))
            SectionCard {
                Eyebrow("About")
                Spacer(Modifier.height(6.dp))
                Text(bio, style = MaterialTheme.typography.bodyMedium, color = Ink)
            }
        }

        // Lifestyle snapshot
        Spacer(Modifier.height(16.dp))
        SectionCard {
            Eyebrow("Lifestyle")
            Spacer(Modifier.height(10.dp))
            val chips = buildList {
                profile?.let { p ->
                    if (p.budget_min != null && p.budget_max != null && p.budget_max > 0) add("₹${p.budget_min}–${p.budget_max}")
                    p.listing_type?.let { add(it) }
                    p.social_energy?.let { add(it) }
                    p.smoking?.let { add(it) }
                    p.drinking?.let { add(it) }
                    p.food_pref?.let { add(it) }
                    p.pets?.let { add(it) }
                    p.cooking_frequency?.let { add("Cooks: $it") }
                }
            }
            if (chips.isEmpty()) Text("Complete your profile to show details.", color = InkSoft, style = MaterialTheme.typography.bodyMedium)
            else FlowRowSimple { chips.forEach { KasaChip(it, selected = false) {} } }

            val tags = (profile?.personality_tags.orEmpty() + profile?.vibes.orEmpty()).distinct()
            if (tags.isNotEmpty()) {
                Spacer(Modifier.height(10.dp))
                Text("Vibe", style = MaterialTheme.typography.labelMedium, color = Muted)
                Spacer(Modifier.height(6.dp))
                FlowRowSimple { tags.forEach { KasaChip(it, selected = false) {} } }
            }
        }

        Spacer(Modifier.height(20.dp))
        Column(Modifier.fillMaxWidth().padding(horizontal = 24.dp)) {
            PrimaryButton("Edit profile", onClick = onEdit)
            Spacer(Modifier.height(10.dp))
            GhostButton("Sign out", onClick = onSignOut)
        }
        Spacer(Modifier.height(28.dp))
    }
}

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = CreamSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
    ) {
        Column(Modifier.padding(18.dp), content = content)
    }
}

@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
private fun FlowRowSimpleCentered(content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}
