package com.kasamates.app.core.network

import com.kasamates.app.core.network.dto.*
import okhttp3.MultipartBody
import retrofit2.http.*

/**
 * Full surface of the Kasamates App Backend (FastAPI), prefix /api/v1.
 * Protected endpoints require Authorization: Bearer <access_token>,
 * which is attached automatically by AuthInterceptor.
 */
interface KasaApi {

    // ---------------- Auth ----------------
    @POST("api/v1/auth/register")
    suspend fun register(@Body body: RegisterRequest): TokenResponse

    @POST("api/v1/auth/login")
    suspend fun login(@Body body: LoginRequest): TokenResponse

    @POST("api/v1/auth/send-otp")
    suspend fun sendOtp(@Body body: SendOtpRequest): MessageResponse

    @POST("api/v1/auth/verify-otp")
    suspend fun verifyOtp(@Body body: VerifyOtpRequest): MessageResponse

    @POST("api/v1/auth/refresh")
    suspend fun refresh(@Body body: RefreshRequest): TokenResponse

    @GET("api/v1/auth/me")
    suspend fun me(): UserOut

    // ---------------- Users ----------------
    @GET("api/v1/users/me")
    suspend fun getProfile(): UserOut

    @PUT("api/v1/users/me")
    suspend fun updateProfile(@Body body: UpdateUserRequest): UserOut

    @Multipart
    @POST("api/v1/users/me/photo")
    suspend fun uploadPhoto(@Part photo: MultipartBody.Part): PhotoUploadResponse

    // -------------- Onboarding --------------
    @GET("api/v1/onboarding/status")
    suspend fun onboardingStatus(): OnboardingStatus

    @POST("api/v1/onboarding/step/1-basic-info")
    suspend fun step1(@Body body: StepBasicInfo): MessageResponse

    @POST("api/v1/onboarding/step/2-lifestyle")
    suspend fun step2(@Body body: StepLifestyle): MessageResponse

    @POST("api/v1/onboarding/step/3-cleanliness")
    suspend fun step3(@Body body: StepCleanliness): MessageResponse

    @POST("api/v1/onboarding/step/4-social")
    suspend fun step4(@Body body: StepSocial): MessageResponse

    @POST("api/v1/onboarding/step/5-values")
    suspend fun step5(@Body body: StepValues): MessageResponse

    @POST("api/v1/onboarding/step/6-preferences")
    suspend fun step6(@Body body: StepPreferences): MessageResponse

    @GET("api/v1/onboarding/profile")
    suspend fun myOnboardingProfile(): ProfileOut

    // ------------- Browse / Match -------------
    @GET("api/v1/matches/browse")
    suspend fun browse(
        @Query("location") location: String? = null,
        @Query("budget_min") budgetMin: Int? = null,
        @Query("budget_max") budgetMax: Int? = null,
        @Query("gender") gender: String? = null,
        @Query("listing_type") listingType: String? = null,
        @Query("smoking") smoking: String? = null,
        @Query("pets") pets: String? = null,
        @Query("min_compatibility") minCompatibility: Int? = null,
        @Query("include_web_users") includeWebUsers: Boolean = true,
        @Query("ai_blurbs") aiBlurbs: Boolean = false,
        @Query("page") page: Int = 1,
        @Query("page_size") pageSize: Int = 20,
    ): BrowseResponse

    @POST("api/v1/matches/interaction")
    suspend fun interact(
        @Query("target_id") targetId: Int,
        @Query("target_source") targetSource: String,
        @Query("interaction_type") interactionType: String,
    ): MessageResponse

    // ---------------- Messaging ----------------
    @POST("api/v1/messages/send")
    suspend fun sendMessage(@Body body: SendMessageRequest): MessageOut

    @GET("api/v1/messages/conversations")
    suspend fun conversations(): List<ConversationOut>

    @GET("api/v1/messages/conversation/{otherUserId}")
    suspend fun conversation(
        @Path("otherUserId") otherUserId: Int,
        @Query("page") page: Int = 1,
        @Query("page_size") pageSize: Int = 50,
    ): List<MessageOut>

    // ------------------- AI -------------------
    @POST("api/v1/ai/match-blurb/{targetUserId}")
    suspend fun matchBlurb(
        @Path("targetUserId") targetUserId: Int,
        @Query("compatibility_score") score: Int = 0,
    ): BlurbResponse

    @POST("api/v1/ai/conflict-predict/{targetUserId}")
    suspend fun conflictPredict(@Path("targetUserId") targetUserId: Int): ReportResponse
}
