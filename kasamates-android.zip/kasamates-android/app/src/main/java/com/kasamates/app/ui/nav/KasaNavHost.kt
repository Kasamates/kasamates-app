package com.kasamates.app.ui.nav

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.NavType
import androidx.navigation.navArgument
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.feature.auth.AuthScreen
import com.kasamates.app.feature.auth.AuthViewModel
import com.kasamates.app.feature.auth.OtpScreen
import com.kasamates.app.feature.chat.ChatScreen
import com.kasamates.app.feature.home.HomeScaffold
import com.kasamates.app.feature.onboarding.OnboardingFlow
import com.kasamates.app.feature.profile.EditProfileScreen
import com.kasamates.app.ui.common.FullScreenLoader
import java.net.URLDecoder
import java.net.URLEncoder

/** Central list of navigation routes. */
object Routes {
    const val SPLASH = "splash"
    const val AUTH = "auth"
    const val OTP = "otp"
    const val ONBOARDING = "onboarding"
    const val HOME = "home"
    const val EDIT_PROFILE = "edit_profile"
    const val CHAT = "chat/{otherId}/{name}"

    fun chat(otherId: Int, name: String): String =
        "chat/$otherId/${URLEncoder.encode(name.ifBlank { "Chat" }, "UTF-8")}"
}

@Composable
fun KasaNavHost(nav: NavHostController = rememberNavController()) {
    NavHost(navController = nav, startDestination = Routes.SPLASH) {

        composable(Routes.SPLASH) {
            val vm = kasaViewModel<AuthViewModel>()
            SplashGate(
                resolve = vm::resolveStartDestination,
                onResolved = { dest ->
                    nav.navigate(dest) {
                        popUpTo(Routes.SPLASH) { inclusive = true }
                    }
                },
            )
        }

        composable(Routes.AUTH) {
            AuthScreen(
                onAuthed = { needsOtp ->
                    val dest = if (needsOtp) Routes.OTP else Routes.ONBOARDING
                    nav.navigate(dest) { popUpTo(Routes.AUTH) { inclusive = true } }
                },
            )
        }

        composable(Routes.OTP) {
            OtpScreen(
                onVerified = {
                    nav.navigate(Routes.ONBOARDING) { popUpTo(Routes.OTP) { inclusive = true } }
                },
            )
        }

        composable(Routes.ONBOARDING) {
            OnboardingFlow(
                onComplete = {
                    nav.navigate(Routes.HOME) { popUpTo(Routes.ONBOARDING) { inclusive = true } }
                },
            )
        }

        composable(Routes.HOME) {
            HomeScaffold(
                onOpenChat = { id, name -> nav.navigate(Routes.chat(id, name)) },
                onEditProfile = { nav.navigate(Routes.EDIT_PROFILE) },
                onSignOut = {
                    nav.navigate(Routes.AUTH) { popUpTo(Routes.HOME) { inclusive = true } }
                },
            )
        }

        composable(Routes.EDIT_PROFILE) {
            EditProfileScreen(onDone = { nav.popBackStack() })
        }

        composable(
            route = Routes.CHAT,
            arguments = listOf(
                navArgument("otherId") { type = NavType.IntType },
                navArgument("name") { type = NavType.StringType },
            ),
        ) { backStack ->
            val otherId = backStack.arguments?.getInt("otherId") ?: 0
            val name = URLDecoder.decode(backStack.arguments?.getString("name") ?: "Chat", "UTF-8")
            ChatScreen(otherUserId = otherId, otherName = name, onBack = { nav.popBackStack() })
        }
    }
}

/** Shows a loader while we decide where a returning user should land. */
@Composable
private fun SplashGate(
    resolve: suspend () -> String,
    onResolved: (String) -> Unit,
) {
    LaunchedEffect(Unit) { onResolved(resolve()) }
    FullScreenLoader()
}
