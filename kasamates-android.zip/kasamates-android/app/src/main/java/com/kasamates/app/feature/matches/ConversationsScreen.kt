package com.kasamates.app.feature.matches

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.core.network.dto.ConversationOut
import com.kasamates.app.ui.theme.*

@Composable
fun ConversationsScreen(onOpenChat: (Int, String) -> Unit) {
    val vm = kasaViewModel<MatchesViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()

    LaunchedEffect(Unit) { vm.load() }

    Column(Modifier.fillMaxSize().background(Cream)) {
        Text(
            "Messages",
            fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink,
            modifier = Modifier.padding(start = 24.dp, top = 16.dp, bottom = 8.dp),
        )
        when {
            ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = GreenPrimary) }
            ui.error != null -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text(ui.error!!, color = InkSoft) }
            ui.items.isEmpty() -> EmptyConversations()
            else -> LazyColumn(Modifier.fillMaxSize()) {
                items(ui.items, key = { it.other_user_id }) { c ->
                    ConversationRow(c, vm.absUrl) { onOpenChat(c.other_user_id, c.other_user_name ?: "Chat") }
                    HorizontalDivider(color = Line, modifier = Modifier.padding(start = 88.dp))
                }
            }
        }
    }
}

@Composable
private fun ConversationRow(c: ConversationOut, absUrl: (String?) -> String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 20.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Avatar(name = c.other_user_name, photo = absUrl(c.other_user_photo))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(c.other_user_name ?: "Housemate", fontWeight = FontWeight.SemiBold, color = Ink, fontSize = 16.sp, maxLines = 1)
            Text(c.last_message ?: "Say hello 👋", style = MaterialTheme.typography.bodyMedium, color = InkSoft, maxLines = 1)
        }
        if (c.unread_count > 0) {
            Spacer(Modifier.width(8.dp))
            Surface(color = GreenPrimary, shape = CircleShape) {
                Text(
                    c.unread_count.toString(),
                    color = Cream, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp),
                )
            }
        }
    }
}

@Composable
fun Avatar(name: String?, photo: String?, size: Int = 52) {
    Surface(shape = CircleShape, color = GreenAccent, modifier = Modifier.size(size.dp).clip(CircleShape)) {
        if (photo != null) {
            AsyncImage(model = photo, contentDescription = name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
        } else {
            Box(contentAlignment = Alignment.Center) {
                Text(name?.take(1)?.uppercase() ?: "?", color = Cream, fontWeight = FontWeight.Bold, fontSize = (size / 2.6f).sp)
            }
        }
    }
}

@Composable
private fun EmptyConversations() {
    Column(
        Modifier.fillMaxSize().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
    ) {
        Text("No messages yet", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 20.sp, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text("Match with someone in Discover to start a conversation.", style = MaterialTheme.typography.bodyMedium, color = InkSoft, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
    }
}
