package com.kasamates.app

import android.app.Application
import com.kasamates.app.core.di.Graph
import com.kasamates.app.core.di.KasaViewModelFactory

class KasaApp : Application() {
    lateinit var graph: Graph
        private set
    lateinit var factory: KasaViewModelFactory
        private set

    override fun onCreate() {
        super.onCreate()
        graph = Graph(this)
        factory = KasaViewModelFactory(graph.repository)
    }
}
