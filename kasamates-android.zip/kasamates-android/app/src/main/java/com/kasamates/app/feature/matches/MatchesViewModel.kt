package com.kasamates.app.feature.matches

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.network.dto.ConversationOut
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class MatchesUi(
    val loading: Boolean = true,
    val error: String? = null,
    val items: List<ConversationOut> = emptyList(),
)

class MatchesViewModel(private val repo: KasaRepository) : ViewModel() {

    private val _ui = MutableStateFlow(MatchesUi())
    val ui = _ui.asStateFlow()

    val absUrl: (String?) -> String? get() = repo::absUrl

    init { load() }

    fun load() {
        _ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            repo.conversations().fold(
                onSuccess = { list -> _ui.update { it.copy(loading = false, items = list) } },
                onFailure = { e -> _ui.update { it.copy(loading = false, error = e.message) } },
            )
        }
    }
}
