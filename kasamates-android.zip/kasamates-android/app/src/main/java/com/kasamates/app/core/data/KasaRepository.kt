package com.kasamates.app.core.data

import com.kasamates.app.core.network.KasaApi
import com.kasamates.app.core.network.dto.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import retrofit2.HttpException

class KasaRepository(
    private val api: KasaApi,
    private val tokens: TokenStore,
    private val baseUrl: String,
) {
    val currentUserId: Int get() = tokens.userId
    val isLoggedIn: Boolean get() = tokens.isLoggedIn

    /** Turns a relative "/uploads/x.jpg" into an absolute URL the image loader can use. */
    fun absUrl(path: String?): String? {
        if (path.isNullOrBlank()) return null
        if (path.startsWith("http")) return path
        val base = baseUrl.trimEnd('/')
        return if (path.startsWith("/")) base + path else "$base/$path"
    }

    // ---------------- Auth ----------------
    suspend fun register(name: String, email: String, password: String, phone: String?) =
        safe {
            val t = api.register(RegisterRequest(email = email, password = password, name = name, phone = phone))
            tokens.saveTokens(t); t
        }

    suspend fun login(email: String, password: String) = safe {
        val t = api.login(LoginRequest(email, password))
        tokens.saveTokens(t); t
    }

    suspend fun sendOtp(type: String, contact: String) =
        safe { api.sendOtp(SendOtpRequest(contact, type)) }

    suspend fun verifyOtp(type: String, code: String) =
        safe { api.verifyOtp(VerifyOtpRequest(code, type)) }

    suspend fun me() = safe { api.me() }

    fun logout() = tokens.clear()

    // -------------- Onboarding --------------
    suspend fun onboardingStatus() = safe { api.onboardingStatus() }
    suspend fun saveStep1(b: StepBasicInfo) = safe { api.step1(b) }
    suspend fun saveStep2(b: StepLifestyle) = safe { api.step2(b) }
    suspend fun saveStep3(b: StepCleanliness) = safe { api.step3(b) }
    suspend fun saveStep4(b: StepSocial) = safe { api.step4(b) }
    suspend fun saveStep5(b: StepValues) = safe { api.step5(b) }
    suspend fun saveStep6(b: StepPreferences) = safe { api.step6(b) }
    suspend fun myProfile() = safe { api.myOnboardingProfile() }

    // ------------- Browse / Match -------------
    suspend fun browse(
        location: String? = null,
        budgetMin: Int? = null,
        budgetMax: Int? = null,
        gender: String? = null,
        listingType: String? = null,
        minCompatibility: Int? = null,
        aiBlurbs: Boolean = false,
        page: Int = 1,
    ) = safe {
        api.browse(
            location = location, budgetMin = budgetMin, budgetMax = budgetMax,
            gender = gender, listingType = listingType, minCompatibility = minCompatibility,
            aiBlurbs = aiBlurbs, page = page,
        )
    }

    suspend fun interact(targetId: Int, source: String, type: String) =
        safe { api.interact(targetId, source, type) }

    // ---------------- Messaging ----------------
    suspend fun conversations() = safe { api.conversations() }
    suspend fun conversation(otherId: Int) = safe { api.conversation(otherId) }
    suspend fun sendMessage(receiverId: Int, content: String) =
        safe { api.sendMessage(SendMessageRequest(receiverId, content)) }

    // ----------------- Profile -----------------
    suspend fun getUser() = safe { api.getProfile() }
    suspend fun updateUser(b: UpdateUserRequest) = safe { api.updateProfile(b) }

    suspend fun uploadPhoto(bytes: ByteArray, filename: String, mime: String) = safe {
        val body = bytes.toRequestBody(mime.toMediaTypeOrNull())
        val part = MultipartBody.Part.createFormData("file", filename, body)
        api.uploadPhoto(part)
    }

    // ------------------- AI -------------------
    suspend fun matchBlurb(targetId: Int, score: Int) =
        safe { api.matchBlurb(targetId, score) }

    /** Runs [block] off the main thread and maps failures to readable messages. */
    private suspend fun <T> safe(block: suspend () -> T): Result<T> =
        withContext(Dispatchers.IO) {
            try {
                Result.success(block())
            } catch (e: HttpException) {
                Result.failure(Exception(parseError(e)))
            } catch (e: Throwable) {
                Result.failure(Exception(e.message ?: "Network error. Check your connection."))
            }
        }

    private fun parseError(e: HttpException): String {
        return try {
            val raw = e.response()?.errorBody()?.string().orEmpty()
            val detail = JSONObject(raw).opt("detail")
            when (detail) {
                is String -> detail
                null -> "Request failed (${e.code()})"
                else -> detail.toString()
            }
        } catch (_: Throwable) {
            "Request failed (${e.code()})"
        }
    }
}
