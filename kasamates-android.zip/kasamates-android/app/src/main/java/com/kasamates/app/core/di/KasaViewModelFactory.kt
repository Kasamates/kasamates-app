package com.kasamates.app.core.di

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext
import com.kasamates.app.KasaApp
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.feature.auth.AuthViewModel
import com.kasamates.app.feature.browse.BrowseViewModel
import com.kasamates.app.feature.chat.ChatViewModel
import com.kasamates.app.feature.matches.MatchesViewModel
import com.kasamates.app.feature.onboarding.OnboardingViewModel
import com.kasamates.app.feature.profile.ProfileViewModel

/** Builds every ViewModel from the shared repository. */
class KasaViewModelFactory(private val repo: KasaRepository) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        return when {
            modelClass.isAssignableFrom(AuthViewModel::class.java) -> AuthViewModel(repo)
            modelClass.isAssignableFrom(OnboardingViewModel::class.java) -> OnboardingViewModel(repo)
            modelClass.isAssignableFrom(BrowseViewModel::class.java) -> BrowseViewModel(repo)
            modelClass.isAssignableFrom(MatchesViewModel::class.java) -> MatchesViewModel(repo)
            modelClass.isAssignableFrom(ChatViewModel::class.java) -> ChatViewModel(repo)
            modelClass.isAssignableFrom(ProfileViewModel::class.java) -> ProfileViewModel(repo)
            else -> throw IllegalArgumentException("Unknown ViewModel: ${modelClass.name}")
        } as T
    }
}

/** Convenience: obtain a Kasamates ViewModel inside any composable. */
@Composable
inline fun <reified VM : ViewModel> kasaViewModel(): VM {
    val app = LocalContext.current.applicationContext as KasaApp
    return viewModel(factory = app.factory)
}
