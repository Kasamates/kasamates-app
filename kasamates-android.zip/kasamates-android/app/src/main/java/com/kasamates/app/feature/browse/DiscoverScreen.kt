package com.kasamates.app.feature.browse

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.core.network.dto.MatchCard
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*
import kotlin.math.abs
import kotlin.math.roundToInt
import kotlinx.coroutines.launch

@Composable
fun DiscoverScreen() {
    val vm = kasaViewModel<BrowseViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()

    Column(Modifier.fillMaxSize().background(Cream)) {
        // Header
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column {
                Text("Discover", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink)
                Text("Housemates that fit your rhythm", style = MaterialTheme.typography.bodySmall, color = InkSoft)
            }
            Spacer(Modifier.weight(1f))
            IconButton(onClick = vm::refresh) { Text("↻", fontSize = 22.sp, color = GreenAccent) }
        }

        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            when {
                ui.loading -> CircularProgressIndicator(color = GreenPrimary)
                ui.error != null -> EmptyState("Couldn't load matches", ui.error!!, onRetry = vm::refresh)
                vm.current == null || ui.endReached && vm.current == null ->
                    EmptyState("You're all caught up", "Check back soon for new housemates.", onRetry = vm::refresh)
                else -> SwipeDeck(ui.cards, ui.index, vm)
            }
        }
    }

    ui.matchWith?.let { card ->
        MatchDialog(card = card, absUrl = vm.absUrl, onDismiss = vm::dismissMatch)
    }
}

@Composable
private fun BoxScope.SwipeDeck(cards: List<MatchCard>, index: Int, vm: BrowseViewModel) {
    // Render the next card underneath for depth, then the draggable top card.
    val next = cards.getOrNull(index + 1)
    if (next != null) {
        CardFace(
            card = next,
            absUrl = vm.absUrl,
            modifier = Modifier.fillMaxWidth(0.9f).fillMaxHeight(0.92f).padding(top = 12.dp).scaleStatic(),
        )
    }
    val top = cards.getOrNull(index) ?: return
    val scope = rememberCoroutineScope()
    val offsetX = remember(index) { Animatable(0f) }

    fun fling(toRight: Boolean, action: () -> Unit) {
        scope.launch {
            offsetX.animateTo(if (toRight) 1600f else -1600f, animationSpec = tween(220))
            action()
        }
    }

    CardFace(
        card = top,
        absUrl = vm.absUrl,
        tintLike = (offsetX.value / 300f).coerceIn(-1f, 1f),
        modifier = Modifier
            .fillMaxWidth(0.92f)
            .fillMaxHeight(0.94f)
            .offset { IntOffset(offsetX.value.roundToInt(), 0) }
            .pointerInput(index) {
                detectDragGestures(
                    onDragEnd = {
                        when {
                            offsetX.value > 280f -> fling(true) { vm.like() }
                            offsetX.value < -280f -> fling(false) { vm.skip() }
                            else -> scope.launch { offsetX.animateTo(0f, tween(200)) }
                        }
                    },
                ) { change, drag ->
                    change.consume()
                    scope.launch { offsetX.snapTo(offsetX.value + drag.x) }
                }
            },
    )

    // Action bar
    Row(
        Modifier.align(Alignment.BottomCenter).padding(bottom = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        RoundAction("✕", SkipClay) { fling(false) { vm.skip() } }
        RoundAction("★", GoldBadge, big = true) { vm.superLike() }
        RoundAction("♥", LikeGreen) { fling(true) { vm.like() } }
    }
}

@Composable
private fun RoundAction(symbol: String, color: androidx.compose.ui.graphics.Color, big: Boolean = false, onClick: () -> Unit) {
    val size = if (big) 68 else 58
    Surface(
        color = CreamHi,
        shape = RoundedCornerShape(50),
        shadowElevation = 4.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        modifier = Modifier.size(size.dp).clip(RoundedCornerShape(50)),
        onClick = onClick,
    ) {
        Box(contentAlignment = Alignment.Center) {
            Text(symbol, color = color, fontSize = (size / 2.4f).sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun CardFace(
    card: MatchCard,
    absUrl: (String?) -> String?,
    modifier: Modifier = Modifier,
    tintLike: Float = 0f,
) {
    val p = card.profile
    Surface(
        shape = RoundedCornerShape(28.dp),
        color = CreamSurface,
        shadowElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        modifier = modifier,
    ) {
        Column {
            Box(Modifier.fillMaxWidth().weight(1f)) {
                val photo = absUrl(card.profile_photo_url)
                if (photo != null) {
                    AsyncImage(
                        model = photo,
                        contentDescription = card.name,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize(),
                    )
                } else {
                    Box(
                        Modifier.fillMaxSize().background(
                            Brush.verticalGradient(listOf(GreenAccent, GreenDeep))
                        ),
                        contentAlignment = Alignment.Center,
                    ) {
                        Text(
                            card.name?.take(1)?.uppercase() ?: "?",
                            color = Cream, fontSize = 72.sp, fontFamily = FontFamily.Serif,
                        )
                    }
                }

                // Like / Skip stamp
                if (abs(tintLike) > 0.08f) {
                    val like = tintLike > 0
                    Text(
                        if (like) "LIKE" else "SKIP",
                        color = if (like) LikeGreen else SkipClay,
                        fontWeight = FontWeight.Black,
                        fontSize = 30.sp,
                        modifier = Modifier
                            .align(if (like) Alignment.TopStart else Alignment.TopEnd)
                            .padding(20.dp),
                    )
                }

                CompatibilityRing(
                    score = card.compatibility_score,
                    modifier = Modifier.align(Alignment.TopEnd).padding(14.dp),
                    size = 56,
                )
            }

            Column(Modifier.padding(18.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        buildString {
                            append(card.name ?: "Someone")
                            card.age?.let { append(", $it") }
                        },
                        fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Ink,
                    )
                    if (card.is_verified_badge) {
                        Spacer(Modifier.width(8.dp)); Text("✓", color = LikeGreen, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.weight(1f))
                    if (card.source == "web") {
                        Surface(color = GoldBadge.copy(alpha = 0.16f), shape = RoundedCornerShape(50)) {
                            Text("Web", color = GoldBadge, style = MaterialTheme.typography.labelSmall, modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp))
                        }
                    }
                }
                p?.location?.let { Text(it, style = MaterialTheme.typography.bodyMedium, color = InkSoft) }
                p?.let {
                    if (it.budget_min != null && it.budget_max != null) {
                        Text("₹${it.budget_min}–₹${it.budget_max}/mo", style = MaterialTheme.typography.bodyMedium, color = GreenAccent)
                    }
                }
                val tags = (p?.vibes.orEmpty() + p?.personality_tags.orEmpty()).distinct().take(4)
                if (tags.isNotEmpty()) {
                    Spacer(Modifier.height(10.dp))
                    FlowRowSimple { tags.forEach { KasaChip(it, selected = false) {} } }
                }
                card.ai_blurb?.let {
                    Spacer(Modifier.height(10.dp))
                    Text("“$it”", style = MaterialTheme.typography.bodyMedium, color = InkSoft)
                }
            }
        }
    }
}

@Composable
private fun MatchDialog(card: MatchCard, absUrl: (String?) -> String?, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = CreamSurface,
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Say hi", color = GreenPrimary, fontWeight = FontWeight.Bold) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Keep browsing", color = InkSoft) } },
        title = {
            Text("It's a match!", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 24.sp, color = Ink, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth())
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.fillMaxWidth()) {
                val photo = absUrl(card.profile_photo_url)
                Surface(shape = RoundedCornerShape(50), modifier = Modifier.size(96.dp), color = GreenAccent) {
                    if (photo != null) {
                        AsyncImage(model = photo, contentDescription = card.name, contentScale = ContentScale.Crop, modifier = Modifier.fillMaxSize())
                    } else {
                        Box(contentAlignment = Alignment.Center) {
                            Text(card.name?.take(1)?.uppercase() ?: "?", color = Cream, fontSize = 40.sp)
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text("You and ${card.name ?: "your match"} both said yes.", color = InkSoft, textAlign = TextAlign.Center)
            }
        },
    )
}

@Composable
private fun EmptyState(title: String, body: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 22.sp, color = Ink, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(body, style = MaterialTheme.typography.bodyMedium, color = InkSoft, textAlign = TextAlign.Center)
        Spacer(Modifier.height(20.dp))
        GhostButton("Refresh", onRetry, modifier = Modifier.fillMaxWidth(0.6f))
    }
}

/** Slight scale-down for the underlying card in the deck. */
private fun Modifier.scaleStatic(): Modifier = this
