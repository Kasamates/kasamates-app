package com.kasamates.app.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val KasaColors = lightColorScheme(
    primary = GreenPrimary,
    onPrimary = Cream,
    secondary = GreenAccent,
    onSecondary = Cream,
    background = Cream,
    onBackground = Ink,
    surface = CreamSurface,
    onSurface = Ink,
    surfaceVariant = CreamHi,
    onSurfaceVariant = InkSoft,
    outline = Muted,
    error = SkipClay,
)

@Composable
fun KasamatesTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    // The brand is intentionally a single warm light identity; we keep it
    // consistent rather than auto-inverting to a generic dark theme.
    MaterialTheme(
        colorScheme = KasaColors,
        typography = KasaTypography,
        content = content
    )
}
