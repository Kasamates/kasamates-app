package com.kasamates.app.feature.onboarding

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.network.dto.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

/** Every field collected across the 6 onboarding steps. Strings keep text fields simple. */
data class OnbForm(
    // Step 1 — basics
    val name: String = "", val age: String = "", val gender: String = "",
    val occupation: String = "", val listingType: String = "",
    // Step 2 — lifestyle
    val wakeTime: String = "07:00", val sleepTime: String = "23:00",
    val noiseTolerance: Float = 50f, val cooking: String = "",
    // Step 3 — cleanliness
    val cleanliness: Float = 50f, val cleaningSchedule: String = "",
    val organization: Set<String> = emptySet(),
    // Step 4 — social
    val socialEnergy: String = "", val guestFrequency: String = "", val aloneTime: Float = 50f,
    // Step 5 — values
    val workLife: String = "", val values: Set<String> = emptySet(), val conflict: String = "",
    // Step 6 — preferences
    val pets: String = "", val smoking: String = "", val drinking: String = "",
    val budgetMin: String = "", val budgetMax: String = "",
    val location: String = "", val locationPrefs: Set<String> = emptySet(),
    val foodPref: String = "", val bio: String = "",
)

data class OnbUi(
    val step: Int = 1,
    val loading: Boolean = false,
    val prefilling: Boolean = true,
    val error: String? = null,
)

class OnboardingViewModel(private val repo: KasaRepository) : ViewModel() {

    val form = MutableStateFlow(OnbForm())
    private val _ui = MutableStateFlow(OnbUi())
    val ui = _ui.asStateFlow()

    val totalSteps = 6

    init {
        viewModelScope.launch {
            // Resume at the first unfinished step.
            repo.onboardingStatus().getOrNull()?.let { st ->
                val resumeAt = if (st.onboarding_step >= 6) 6 else (st.onboarding_step + 1).coerceIn(1, 6)
                _ui.update { it.copy(step = resumeAt) }
            }
            // Pre-fill anything already known so users don't retype.
            repo.me().getOrNull()?.let { me ->
                form.update {
                    it.copy(
                        name = me.name.orEmpty().ifBlank { it.name },
                        age = me.age?.toString().orEmpty().ifBlank { it.age },
                        gender = me.gender.orEmpty().ifBlank { it.gender },
                    )
                }
            }
            repo.myProfile().getOrNull()?.let { p -> prefillFromProfile(p) }
            _ui.update { it.copy(prefilling = false) }
        }
    }

    private fun prefillFromProfile(p: ProfileOut) = form.update {
        it.copy(
            occupation = p.occupation.orEmpty().ifBlank { it.occupation },
            listingType = p.listing_type.orEmpty().ifBlank { it.listingType },
            wakeTime = p.wake_time ?: it.wakeTime,
            sleepTime = p.sleep_time ?: it.sleepTime,
            noiseTolerance = p.noise_tolerance?.toFloat() ?: it.noiseTolerance,
            cooking = p.cooking_frequency.orEmpty().ifBlank { it.cooking },
            cleanliness = p.cleanliness_level?.toFloat() ?: it.cleanliness,
            cleaningSchedule = p.cleaning_schedule.orEmpty().ifBlank { it.cleaningSchedule },
            organization = p.organization_style?.toSet() ?: it.organization,
            socialEnergy = p.social_energy.orEmpty().ifBlank { it.socialEnergy },
            guestFrequency = p.guest_frequency.orEmpty().ifBlank { it.guestFrequency },
            aloneTime = p.alone_time_importance?.toFloat() ?: it.aloneTime,
            workLife = p.work_life_balance.orEmpty().ifBlank { it.workLife },
            values = p.important_values?.toSet() ?: it.values,
            conflict = p.conflict_resolution.orEmpty().ifBlank { it.conflict },
            pets = p.pets.orEmpty().ifBlank { it.pets },
            smoking = p.smoking.orEmpty().ifBlank { it.smoking },
            drinking = p.drinking.orEmpty().ifBlank { it.drinking },
            budgetMin = p.budget_min?.takeIf { v -> v > 0 }?.toString().orEmpty().ifBlank { it.budgetMin },
            budgetMax = p.budget_max?.takeIf { v -> v > 0 }?.toString().orEmpty().ifBlank { it.budgetMax },
            location = p.location.orEmpty().ifBlank { it.location },
            locationPrefs = p.location_preferences?.toSet() ?: it.locationPrefs,
            foodPref = p.food_pref.orEmpty().ifBlank { it.foodPref },
            bio = p.bio.orEmpty().ifBlank { it.bio },
        )
    }

    fun set(block: (OnbForm) -> OnbForm) = form.update(block)

    fun back() = _ui.update { if (it.step > 1) it.copy(step = it.step - 1, error = null) else it }

    fun next(onComplete: () -> Unit) {
        val f = form.value
        val step = _ui.value.step
        validate(step, f)?.let { msg -> _ui.update { it.copy(error = msg) }; return }

        _ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val result = when (step) {
                1 -> repo.saveStep1(
                    StepBasicInfo(
                        name = f.name.trim(), age = f.age.toInt(), gender = f.gender,
                        occupation = f.occupation.ifBlank { null },
                        listing_type = f.listingType.ifBlank { null },
                    )
                )
                2 -> repo.saveStep2(
                    StepLifestyle(
                        wake_time = f.wakeTime, sleep_time = f.sleepTime,
                        noise_tolerance = f.noiseTolerance.toInt(), cooking_frequency = f.cooking,
                    )
                )
                3 -> repo.saveStep3(
                    StepCleanliness(
                        cleanliness_level = f.cleanliness.toInt(),
                        cleaning_schedule = f.cleaningSchedule,
                        organization_style = f.organization.toList(),
                    )
                )
                4 -> repo.saveStep4(
                    StepSocial(
                        social_energy = f.socialEnergy, guest_frequency = f.guestFrequency,
                        alone_time_importance = f.aloneTime.toInt(),
                    )
                )
                5 -> repo.saveStep5(
                    StepValues(
                        work_life_balance = f.workLife,
                        important_values = f.values.toList(),
                        conflict_resolution = f.conflict,
                    )
                )
                else -> repo.saveStep6(
                    StepPreferences(
                        pets = f.pets, smoking = f.smoking, drinking = f.drinking,
                        budget_min = f.budgetMin.toInt(), budget_max = f.budgetMax.toInt(),
                        location = f.location, location_preferences = f.locationPrefs.toList(),
                        food_pref = f.foodPref.ifBlank { null }, bio = f.bio.ifBlank { null },
                    )
                )
            }
            result.fold(
                onSuccess = {
                    _ui.update { it.copy(loading = false) }
                    if (step >= totalSteps) onComplete() else _ui.update { it.copy(step = step + 1) }
                },
                onFailure = { e -> _ui.update { it.copy(loading = false, error = e.message) } },
            )
        }
    }

    private fun validate(step: Int, f: OnbForm): String? = when (step) {
        1 -> when {
            f.name.isBlank() -> "Please enter your name."
            f.age.toIntOrNull() == null -> "Enter your age as a number."
            f.age.toInt() !in 18..99 -> "Age must be between 18 and 99."
            f.gender.isBlank() -> "Select how you identify."
            else -> null
        }
        2 -> if (f.cooking.isBlank()) "Tell us how often you cook." else null
        3 -> if (f.cleaningSchedule.isBlank()) "Pick a cleaning rhythm." else null
        4 -> when {
            f.socialEnergy.isBlank() -> "Pick your social energy."
            f.guestFrequency.isBlank() -> "How often do guests come over?"
            else -> null
        }
        5 -> when {
            f.workLife.isBlank() -> "Pick your work–life balance."
            f.conflict.isBlank() -> "How do you handle disagreements?"
            else -> null
        }
        6 -> when {
            f.pets.isBlank() -> "Share your stance on pets."
            f.smoking.isBlank() -> "Share your smoking preference."
            f.drinking.isBlank() -> "Share your drinking preference."
            f.budgetMin.toIntOrNull() == null || f.budgetMax.toIntOrNull() == null -> "Enter a numeric budget range."
            f.budgetMin.toInt() > f.budgetMax.toInt() -> "Minimum budget can't exceed the maximum."
            f.location.isBlank() -> "Where are you looking to live?"
            else -> null
        }
        else -> null
    }
}
