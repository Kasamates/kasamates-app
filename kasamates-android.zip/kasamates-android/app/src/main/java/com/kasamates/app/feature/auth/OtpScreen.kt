package com.kasamates.app.feature.auth

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*

@Composable
fun OtpScreen(onVerified: () -> Unit) {
    val vm = kasaViewModel<AuthViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()
    var code by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Cream)
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Spacer(Modifier.height(96.dp))
        Text("Verify your email", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 30.sp, color = Ink)
        Spacer(Modifier.height(10.dp))
        Text(
            buildString {
                append("Enter the 6-digit code we sent")
                if (vm.lastEmail.isNotBlank()) append(" to ${vm.lastEmail}")
                append(".")
            },
            style = MaterialTheme.typography.bodyMedium,
            color = InkSoft,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(32.dp))

        KasaField(code, { if (it.length <= 6) code = it.filter(Char::isDigit) }, "Verification code", keyboardType = KeyboardType.Number)

        ui.info?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = LikeGreen, style = MaterialTheme.typography.labelMedium)
        }
        Spacer(Modifier.height(12.dp))
        ErrorBanner(ui.error)
        Spacer(Modifier.height(8.dp))

        PrimaryButton("Verify", loading = ui.loading, onClick = { vm.verifyEmailOtp(code) { onVerified() } })

        Spacer(Modifier.height(12.dp))
        TextButton(onClick = { vm.resendEmailOtp() }, enabled = !ui.loading) {
            Text("Didn't get it? Resend code", color = GreenAccent)
        }

        Spacer(Modifier.weight(1f))
        Text(
            "Phone verification can be completed later from your profile.",
            style = MaterialTheme.typography.labelSmall,
            color = Muted,
            textAlign = TextAlign.Center,
            modifier = Modifier.padding(bottom = 28.dp),
        )
    }
}
