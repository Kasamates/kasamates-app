package com.kasamates.app.feature.profile

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.network.dto.*
import com.kasamates.app.feature.onboarding.OnbForm
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ProfileUi(
    val loading: Boolean = true,
    val error: String? = null,
    val user: UserOut? = null,
    val profile: ProfileOut? = null,
    val saving: Boolean = false,
)

class ProfileViewModel(private val repo: KasaRepository) : ViewModel() {

    private val _ui = MutableStateFlow(ProfileUi())
    val ui = _ui.asStateFlow()

    val absUrl: (String?) -> String? get() = repo::absUrl

    init { load() }

    fun load() {
        _ui.update { it.copy(loading = true, error = null) }
        viewModelScope.launch {
            val user = repo.getUser().getOrNull()
            val profile = repo.myProfile().getOrNull()
            if (user == null && profile == null) {
                _ui.update { it.copy(loading = false, error = "Couldn't load your profile.") }
            } else {
                _ui.update { it.copy(loading = false, user = user, profile = profile) }
            }
        }
    }

    fun signOut(onDone: () -> Unit) {
        repo.logout()
        onDone()
    }

    /** Build an editable form snapshot from what we've loaded. */
    fun toForm(): OnbForm {
        val u = _ui.value.user
        val p = _ui.value.profile
        return OnbForm(
            name = u?.name.orEmpty(),
            age = u?.age?.toString().orEmpty(),
            gender = u?.gender.orEmpty(),
            occupation = p?.occupation.orEmpty(),
            listingType = p?.listing_type.orEmpty(),
            wakeTime = p?.wake_time ?: "07:00",
            sleepTime = p?.sleep_time ?: "23:00",
            noiseTolerance = (p?.noise_tolerance ?: 50).toFloat(),
            cooking = p?.cooking_frequency.orEmpty(),
            cleanliness = (p?.cleanliness_level ?: 50).toFloat(),
            cleaningSchedule = p?.cleaning_schedule.orEmpty(),
            organization = p?.organization_style?.toSet() ?: emptySet(),
            socialEnergy = p?.social_energy.orEmpty(),
            guestFrequency = p?.guest_frequency.orEmpty(),
            aloneTime = (p?.alone_time_importance ?: 50).toFloat(),
            workLife = p?.work_life_balance.orEmpty(),
            values = p?.important_values?.toSet() ?: emptySet(),
            conflict = p?.conflict_resolution.orEmpty(),
            pets = p?.pets.orEmpty(),
            smoking = p?.smoking.orEmpty(),
            drinking = p?.drinking.orEmpty(),
            budgetMin = p?.budget_min?.takeIf { it > 0 }?.toString().orEmpty(),
            budgetMax = p?.budget_max?.takeIf { it > 0 }?.toString().orEmpty(),
            location = p?.location.orEmpty(),
            locationPrefs = p?.location_preferences?.toSet() ?: emptySet(),
            foodPref = p?.food_pref.orEmpty(),
            bio = p?.bio.orEmpty(),
        )
    }

    /** Persist edits by re-submitting the onboarding step endpoints (they upsert). */
    fun saveAll(f: OnbForm, onDone: () -> Unit) {
        _ui.update { it.copy(saving = true, error = null) }
        viewModelScope.launch {
            val steps = listOf<suspend () -> Result<*>>(
                { repo.saveStep1(StepBasicInfo(f.name.trim(), f.age.toIntOrNull() ?: 18, f.gender.ifBlank { "Prefer not to say" }, f.occupation.ifBlank { null }, f.listingType.ifBlank { null })) },
                { repo.saveStep2(StepLifestyle(f.wakeTime, f.sleepTime, f.noiseTolerance.toInt(), f.cooking.ifBlank { "Sometimes" })) },
                { repo.saveStep3(StepCleanliness(f.cleanliness.toInt(), f.cleaningSchedule.ifBlank { "Weekly" }, f.organization.toList())) },
                { repo.saveStep4(StepSocial(f.socialEnergy.ifBlank { "Ambivert" }, f.guestFrequency.ifBlank { "Occasionally" }, f.aloneTime.toInt())) },
                { repo.saveStep5(StepValues(f.workLife.ifBlank { "Balanced" }, f.values.toList(), f.conflict.ifBlank { "Talk it out" })) },
                { repo.saveStep6(StepPreferences(f.pets.ifBlank { "No pets" }, f.smoking.ifBlank { "Non-smoker" }, f.drinking.ifBlank { "Non-drinker" }, f.budgetMin.toIntOrNull() ?: 0, f.budgetMax.toIntOrNull() ?: 0, f.location, f.locationPrefs.toList(), f.foodPref.ifBlank { null }, f.bio.ifBlank { null })) },
            )
            for (call in steps) {
                val r = call()
                if (r.isFailure) {
                    _ui.update { it.copy(saving = false, error = r.exceptionOrNull()?.message ?: "Couldn't save changes.") }
                    return@launch
                }
            }
            load()
            _ui.update { it.copy(saving = false) }
            onDone()
        }
    }
}
