package com.kasamates.app.feature.onboarding

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*

private object Opt {
    val gender = listOf("Male", "Female", "Non-binary", "Prefer not to say")
    val listing = listOf("Seeking a room", "Offering a room", "Seeking a flatmate")
    val cooking = listOf("Rarely", "Sometimes", "Often", "Daily")
    val cleaning = listOf("As needed", "Weekly", "Twice a week", "Daily")
    val organization = listOf("Minimalist", "Label everything", "Organized chaos", "Shared chores", "Tidy as I go")
    val social = listOf("Introvert", "Ambivert", "Extrovert")
    val guests = listOf("Rarely", "Occasionally", "Frequently")
    val workLife = listOf("Work-focused", "Balanced", "Life-focused")
    val values = listOf("Honesty", "Cleanliness", "Quiet", "Sociable", "Privacy", "Sustainability", "Fitness", "Spiritual")
    val conflict = listOf("Talk it out", "Give space", "Address it early", "Avoid conflict")
    val pets = listOf("No pets", "Have a pet", "Pet friendly", "Allergic")
    val smoking = listOf("Non-smoker", "Smoker", "Occasional", "Outside only")
    val drinking = listOf("Non-drinker", "Social drinker", "Regular")
    val food = listOf("Vegetarian", "Vegan", "Non-veg", "Eggetarian", "Jain")
    val areas = listOf("Gurugram", "Noida", "Faridabad", "South Delhi", "Dwarka", "Greater Noida")
    // (label shown, value stored as HH:MM)
    val bedtimes = listOf("9 PM" to "21:00", "10 PM" to "22:00", "11 PM" to "23:00", "12 AM" to "00:00", "1 AM" to "01:00", "2 AM" to "02:00")
    val waketimes = listOf("5 AM" to "05:00", "6 AM" to "06:00", "7 AM" to "07:00", "8 AM" to "08:00", "9 AM" to "09:00", "10 AM" to "10:00")
}

@Composable
fun OnboardingFlow(onComplete: () -> Unit) {
    val vm = kasaViewModel<OnboardingViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()
    val f by vm.form.collectAsStateWithLifecycle()

    if (ui.prefilling) { FullScreenLoader(); return }

    Column(Modifier.fillMaxSize().background(Cream)) {
        // Progress header
        Column(Modifier.padding(horizontal = 24.dp, vertical = 18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (ui.step > 1) {
                    TextButton(onClick = vm::back, contentPadding = PaddingValues(0.dp)) {
                        Text("← Back", color = GreenAccent)
                    }
                }
                Spacer(Modifier.weight(1f))
                Text("Step ${ui.step} of ${vm.totalSteps}", style = MaterialTheme.typography.labelMedium, color = Muted)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(
                progress = { ui.step / vm.totalSteps.toFloat() },
                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(50)),
                color = GreenPrimary,
                trackColor = Line,
            )
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        ) {
            when (ui.step) {
                1 -> StepBasics(f, vm)
                2 -> StepLifestyleUi(f, vm)
                3 -> StepCleanlinessUi(f, vm)
                4 -> StepSocialUi(f, vm)
                5 -> StepValuesUi(f, vm)
                else -> StepPreferencesUi(f, vm)
            }
            Spacer(Modifier.height(16.dp))
            ErrorBanner(ui.error)
            Spacer(Modifier.height(24.dp))
        }

        Box(Modifier.padding(24.dp)) {
            PrimaryButton(
                text = if (ui.step >= vm.totalSteps) "Finish" else "Continue",
                loading = ui.loading,
                onClick = { vm.next(onComplete) },
            )
        }
    }
}

@Composable
private fun StepHeader(eyebrow: String, title: String, subtitle: String? = null) {
    Eyebrow(eyebrow)
    Spacer(Modifier.height(8.dp))
    Text(title, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, fontSize = 26.sp, color = Ink, lineHeight = 30.sp)
    if (subtitle != null) {
        Spacer(Modifier.height(6.dp))
        Text(subtitle, style = MaterialTheme.typography.bodyMedium, color = InkSoft)
    }
    Spacer(Modifier.height(20.dp))
}

@Composable
private fun FieldLabel(text: String) {
    Text(text, style = MaterialTheme.typography.titleSmall, color = Ink, modifier = Modifier.padding(bottom = 8.dp, top = 4.dp))
}

@Composable
private fun SingleChips(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    FlowRowSimple {
        options.forEach { opt -> KasaChip(opt, selected == opt) { onSelect(opt) } }
    }
}

@Composable
private fun TimeChips(options: List<Pair<String, String>>, selected: String, onSelect: (String) -> Unit) {
    FlowRowSimple {
        options.forEach { (label, value) -> KasaChip(label, selected == value) { onSelect(value) } }
    }
}

/* ----------------------------- Steps ----------------------------- */

@Composable
private fun StepBasics(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("About you", "The basics", "Let's start with a quick introduction.")
    KasaField(f.name, { v -> vm.set { it.copy(name = v) } }, "Full name")
    Spacer(Modifier.height(12.dp))
    KasaField(f.age, { v -> vm.set { it.copy(age = v.filter(Char::isDigit).take(2)) } }, "Age", keyboardType = KeyboardType.Number)
    Spacer(Modifier.height(16.dp))
    FieldLabel("Gender")
    SingleChips(Opt.gender, f.gender) { v -> vm.set { it.copy(gender = v) } }
    Spacer(Modifier.height(16.dp))
    KasaField(f.occupation, { v -> vm.set { it.copy(occupation = v) } }, "Occupation (optional)")
    Spacer(Modifier.height(16.dp))
    FieldLabel("What brings you here?")
    SingleChips(Opt.listing, f.listingType) { v -> vm.set { it.copy(listingType = v) } }
}

@Composable
private fun StepLifestyleUi(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("Daily rhythm", "Your routine", "Sleep, noise, and kitchen habits.")
    FieldLabel("Usual bedtime")
    TimeChips(Opt.bedtimes, f.sleepTime) { v -> vm.set { it.copy(sleepTime = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Usual wake-up")
    TimeChips(Opt.waketimes, f.wakeTime) { v -> vm.set { it.copy(wakeTime = v) } }
    Spacer(Modifier.height(20.dp))
    LabeledSlider("Noise tolerance", f.noiseTolerance, { v -> vm.set { it.copy(noiseTolerance = v) } }, "Pin-drop quiet", "Lively")
    Spacer(Modifier.height(16.dp))
    FieldLabel("How often do you cook?")
    SingleChips(Opt.cooking, f.cooking) { v -> vm.set { it.copy(cooking = v) } }
}

@Composable
private fun StepCleanlinessUi(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("Shared space", "Cleanliness", "How you like to keep a home.")
    LabeledSlider("Tidiness level", f.cleanliness, { v -> vm.set { it.copy(cleanliness = v) } }, "Relaxed", "Spotless")
    Spacer(Modifier.height(16.dp))
    FieldLabel("Cleaning rhythm")
    SingleChips(Opt.cleaning, f.cleaningSchedule) { v -> vm.set { it.copy(cleaningSchedule = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Your style (pick any)")
    ChipGroup(Opt.organization, f.organization, { v ->
        vm.set { it.copy(organization = it.organization.toggle(v)) }
    })
}

@Composable
private fun StepSocialUi(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("At home", "Social energy", "How sociable is your ideal home?")
    FieldLabel("You are more…")
    SingleChips(Opt.social, f.socialEnergy) { v -> vm.set { it.copy(socialEnergy = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Guests over")
    SingleChips(Opt.guests, f.guestFrequency) { v -> vm.set { it.copy(guestFrequency = v) } }
    Spacer(Modifier.height(20.dp))
    LabeledSlider("Need for alone time", f.aloneTime, { v -> vm.set { it.copy(aloneTime = v) } }, "Low", "High")
}

@Composable
private fun StepValuesUi(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("What matters", "Your values", "These help us find aligned matches.")
    FieldLabel("Work–life balance")
    SingleChips(Opt.workLife, f.workLife) { v -> vm.set { it.copy(workLife = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Values you hold (pick any)")
    ChipGroup(Opt.values, f.values, { v -> vm.set { it.copy(values = it.values.toggle(v)) } })
    Spacer(Modifier.height(16.dp))
    FieldLabel("Handling disagreements")
    SingleChips(Opt.conflict, f.conflict) { v -> vm.set { it.copy(conflict = v) } }
}

@Composable
private fun StepPreferencesUi(f: OnbForm, vm: OnboardingViewModel) {
    StepHeader("Almost there", "Preferences", "Lifestyle, budget, and where you want to live.")
    FieldLabel("Pets")
    SingleChips(Opt.pets, f.pets) { v -> vm.set { it.copy(pets = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Smoking")
    SingleChips(Opt.smoking, f.smoking) { v -> vm.set { it.copy(smoking = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Drinking")
    SingleChips(Opt.drinking, f.drinking) { v -> vm.set { it.copy(drinking = v) } }
    Spacer(Modifier.height(16.dp))
    FieldLabel("Food preference")
    SingleChips(Opt.food, f.foodPref) { v -> vm.set { it.copy(foodPref = v) } }
    Spacer(Modifier.height(20.dp))
    FieldLabel("Monthly budget (₹)")
    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.weight(1f)) {
            KasaField(f.budgetMin, { v -> vm.set { it.copy(budgetMin = v.filter(Char::isDigit).take(6)) } }, "Min", keyboardType = KeyboardType.Number)
        }
        Box(Modifier.weight(1f)) {
            KasaField(f.budgetMax, { v -> vm.set { it.copy(budgetMax = v.filter(Char::isDigit).take(6)) } }, "Max", keyboardType = KeyboardType.Number)
        }
    }
    Spacer(Modifier.height(16.dp))
    KasaField(f.location, { v -> vm.set { it.copy(location = v) } }, "Primary area (e.g. Gurugram)")
    Spacer(Modifier.height(16.dp))
    FieldLabel("Open to areas (pick any)")
    ChipGroup(Opt.areas, f.locationPrefs, { v -> vm.set { it.copy(locationPrefs = it.locationPrefs.toggle(v)) } })
    Spacer(Modifier.height(16.dp))
    KasaField(f.bio, { v -> vm.set { it.copy(bio = v) } }, "Short bio (optional)", singleLine = false)
}

private fun Set<String>.toggle(v: String): Set<String> =
    if (contains(v)) this - v else this + v
