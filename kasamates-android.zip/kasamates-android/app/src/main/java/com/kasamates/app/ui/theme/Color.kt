package com.kasamates.app.ui.theme

import androidx.compose.ui.graphics.Color

// Palette sampled directly from the KASA design walkthrough.
val Cream        = Color(0xFFF2EBD9) // app canvas
val CreamSurface = Color(0xFFF9F4E9) // cards / sheets
val CreamHi      = Color(0xFFFFFDF7)
val GreenDeep    = Color(0xFF161E11) // splash / hero
val GreenPrimary = Color(0xFF2E3823) // primary buttons, dark olive
val GreenAccent  = Color(0xFF46552F) // secondary accent
val Ink          = Color(0xFF1B1F14) // primary text
val InkSoft      = Color(0xFF5B5C4E) // secondary text
val Muted        = Color(0xFF8A8775) // hints
val Line         = Color(0x1A1B1F14) // hairline borders (~10% ink)
val LikeGreen    = Color(0xFF3C5A2E)
val SkipClay     = Color(0xFF9A5B43)
val GoldBadge    = Color(0xFFB8923E)
