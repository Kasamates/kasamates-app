package com.kasamates.app.core.di

import android.content.Context
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import com.kasamates.app.BuildConfig
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.data.TokenStore
import com.kasamates.app.core.network.AuthInterceptor
import com.kasamates.app.core.network.KasaApi
import com.kasamates.app.core.network.TokenAuthenticator
import com.kasamates.app.core.network.dto.RefreshRequest
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import java.util.concurrent.TimeUnit

/**
 * Tiny manual DI container. Created once in [com.kasamates.app.KasaApp]
 * and reached from ViewModels via the application context.
 */
class Graph(context: Context) {

    val baseUrl: String = BuildConfig.BASE_URL

    val tokens = TokenStore(context)

    private val moshi: Moshi = Moshi.Builder()
        .add(KotlinJsonAdapterFactory())
        .build()

    private val logging = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BODY
        else HttpLoggingInterceptor.Level.NONE
    }

    // Bare client used only to refresh tokens (no authenticator -> no loops).
    private val refreshClient = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val refreshApi: KasaApi = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(refreshClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(KasaApi::class.java)

    private val authenticator = TokenAuthenticator(tokens) { refresh ->
        refreshApi.refresh(RefreshRequest(refresh))
    }

    private val client = OkHttpClient.Builder()
        .addInterceptor(AuthInterceptor(tokens))
        .addInterceptor(logging)
        .authenticator(authenticator)
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .build()

    val api: KasaApi = Retrofit.Builder()
        .baseUrl(baseUrl)
        .client(client)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(KasaApi::class.java)

    val repository = KasaRepository(api, tokens, baseUrl)
}
