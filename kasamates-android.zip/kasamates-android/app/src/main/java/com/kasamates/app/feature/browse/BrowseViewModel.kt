package com.kasamates.app.feature.browse

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.network.dto.MatchCard
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class BrowseUi(
    val loading: Boolean = true,
    val error: String? = null,
    val cards: List<MatchCard> = emptyList(),
    val index: Int = 0,
    val matchWith: MatchCard? = null,
    val endReached: Boolean = false,
)

class BrowseViewModel(private val repo: KasaRepository) : ViewModel() {

    private val _ui = MutableStateFlow(BrowseUi())
    val ui = _ui.asStateFlow()
    private var page = 1
    private var loadingMore = false

    val absUrl: (String?) -> String? get() = repo::absUrl

    init { refresh() }

    val current: MatchCard? get() = _ui.value.cards.getOrNull(_ui.value.index)

    fun refresh() {
        page = 1
        _ui.update { it.copy(loading = true, error = null, endReached = false, index = 0, cards = emptyList()) }
        viewModelScope.launch {
            repo.browse(page = page).fold(
                onSuccess = { r ->
                    _ui.update { it.copy(loading = false, cards = r.results, endReached = r.results.isEmpty()) }
                },
                onFailure = { e -> _ui.update { it.copy(loading = false, error = e.message) } },
            )
        }
    }

    private fun loadMore() {
        if (loadingMore || _ui.value.endReached) return
        loadingMore = true
        page += 1
        viewModelScope.launch {
            repo.browse(page = page).fold(
                onSuccess = { r ->
                    if (r.results.isEmpty()) _ui.update { it.copy(endReached = true) }
                    else _ui.update { it.copy(cards = it.cards + r.results) }
                    loadingMore = false
                },
                onFailure = { loadingMore = false },
            )
        }
    }

    fun like() = act("like")
    fun superLike() = act("like")   // backend has no super-like; treated as a strong like
    fun skip() = act("skip")

    private fun act(type: String) {
        val card = current ?: return
        // Optimistically advance so the UI stays snappy.
        advance()
        viewModelScope.launch {
            repo.interact(card.user_id, card.source, type).onSuccess { msg ->
                val matched = msg.message?.contains("match", ignoreCase = true) == true
                if (matched && type == "like") _ui.update { it.copy(matchWith = card) }
            }
        }
    }

    private fun advance() {
        val next = _ui.value.index + 1
        _ui.update { it.copy(index = next) }
        if (next >= _ui.value.cards.size - 2) loadMore()
        if (next >= _ui.value.cards.size && !loadingMore) _ui.update { it.copy(endReached = true) }
    }

    fun dismissMatch() = _ui.update { it.copy(matchWith = null) }

    /** Like/skip a specific person from the grid without disturbing the swipe deck. */
    fun interactFromList(card: MatchCard, type: String) {
        viewModelScope.launch {
            repo.interact(card.user_id, card.source, type).onSuccess { msg ->
                if (type == "like" && msg.message?.contains("match", ignoreCase = true) == true) {
                    _ui.update { it.copy(matchWith = card) }
                }
            }
        }
    }
}
