package com.kasamates.app.feature.chat

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.core.network.dto.MessageOut
import com.kasamates.app.ui.theme.*
import kotlinx.coroutines.delay

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ChatScreen(otherUserId: Int, otherName: String, onBack: () -> Unit) {
    val vm = kasaViewModel<ChatViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()
    var draft by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    LaunchedEffect(otherUserId) { vm.start(otherUserId) }
    // Lightweight polling while the screen is visible.
    LaunchedEffect(otherUserId) {
        while (true) { delay(5000); vm.refresh() }
    }
    // Keep the newest message in view.
    LaunchedEffect(ui.messages.size) {
        if (ui.messages.isNotEmpty()) listState.animateScrollToItem(ui.messages.size - 1)
    }

    Scaffold(
        containerColor = Cream,
        topBar = {
            TopAppBar(
                title = { Text(otherName, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = Ink) },
                navigationIcon = { TextButton(onClick = onBack) { Text("←", fontSize = 22.sp, color = GreenAccent) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CreamSurface, titleContentColor = Ink),
            )
        },
        bottomBar = {
            MessageComposer(
                value = draft,
                onValueChange = { draft = it },
                sending = ui.sending,
                onSend = { if (draft.isNotBlank()) { vm.send(draft); draft = "" } },
            )
        },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) {
            when {
                ui.loading -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator(color = GreenPrimary) }
                ui.messages.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Text("Say hello to $otherName 👋", color = InkSoft)
                }
                else -> LazyColumn(
                    state = listState,
                    modifier = Modifier.fillMaxSize(),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    items(ui.messages.size) { i ->
                        val m = ui.messages[i]
                        MessageBubble(m, isMine = m.sender_id == vm.myId)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessageBubble(m: MessageOut, isMine: Boolean) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = if (isMine) Arrangement.End else Arrangement.Start) {
        Surface(
            color = if (isMine) GreenPrimary else CreamSurface,
            contentColor = if (isMine) Cream else Ink,
            shape = RoundedCornerShape(
                topStart = 18.dp, topEnd = 18.dp,
                bottomStart = if (isMine) 18.dp else 4.dp,
                bottomEnd = if (isMine) 4.dp else 18.dp,
            ),
            border = if (isMine) null else androidx.compose.foundation.BorderStroke(1.dp, Line),
            modifier = Modifier.widthIn(max = 280.dp),
        ) {
            Text(m.content, modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp), fontSize = 15.sp)
        }
    }
}

@Composable
private fun MessageComposer(value: String, onValueChange: (String) -> Unit, sending: Boolean, onSend: () -> Unit) {
    Surface(color = CreamSurface, shadowElevation = 8.dp) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp).navigationBarsPadding(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            OutlinedTextField(
                value = value,
                onValueChange = onValueChange,
                placeholder = { Text("Message…") },
                shape = RoundedCornerShape(24.dp),
                keyboardOptions = KeyboardOptions.Default,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GreenPrimary,
                    unfocusedBorderColor = Line,
                    focusedContainerColor = CreamHi,
                    unfocusedContainerColor = CreamHi,
                ),
                modifier = Modifier.weight(1f),
                maxLines = 4,
            )
            Spacer(Modifier.width(8.dp))
            Surface(
                color = if (value.isBlank()) GreenPrimary.copy(alpha = 0.4f) else GreenPrimary,
                shape = RoundedCornerShape(50),
                onClick = onSend,
                enabled = value.isNotBlank() && !sending,
                modifier = Modifier.size(50.dp),
            ) {
                Box(contentAlignment = Alignment.Center) {
                    if (sending) CircularProgressIndicator(color = Cream, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
                    else Text("➤", color = Cream, fontSize = 18.sp)
                }
            }
        }
    }
}
