package com.kasamates.app.ui.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kasamates.app.ui.theme.*
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Uppercase tracked eyebrow used above headings throughout KASA. */
@Composable
fun Eyebrow(text: String, modifier: Modifier = Modifier, color: Color = GoldBadge) {
    Text(
        text.uppercase(),
        style = MaterialTheme.typography.labelMedium,
        letterSpacing = 2.sp,
        color = color,
        modifier = modifier,
    )
}

@Composable
fun PrimaryButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    loading: Boolean = false,
) {
    Button(
        onClick = onClick,
        enabled = enabled && !loading,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = GreenPrimary,
            contentColor = Cream,
            disabledContainerColor = GreenPrimary.copy(alpha = 0.4f),
            disabledContentColor = Cream.copy(alpha = 0.7f),
        ),
        contentPadding = PaddingValues(vertical = 16.dp),
        modifier = modifier.fillMaxWidth().heightIn(min = 54.dp),
    ) {
        if (loading) {
            CircularProgressIndicator(color = Cream, strokeWidth = 2.dp, modifier = Modifier.size(20.dp))
        } else {
            Text(text, style = MaterialTheme.typography.labelLarge, fontSize = 16.sp)
        }
    }
}

@Composable
fun GhostButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    OutlinedButton(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Line),
        colors = ButtonDefaults.outlinedButtonColors(contentColor = Ink),
        contentPadding = PaddingValues(vertical = 16.dp),
        modifier = modifier.fillMaxWidth().heightIn(min = 54.dp),
    ) { Text(text, style = MaterialTheme.typography.labelLarge, fontSize = 16.sp) }
}

@Composable
fun KasaField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    isPassword: Boolean = false,
    singleLine: Boolean = true,
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = singleLine,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (isPassword) PasswordVisualTransformation() else androidx.compose.ui.text.input.VisualTransformation.None,
        shape = RoundedCornerShape(14.dp),
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = GreenPrimary,
            unfocusedBorderColor = Line,
            focusedContainerColor = CreamHi,
            unfocusedContainerColor = CreamHi,
            cursorColor = GreenPrimary,
            focusedLabelColor = GreenAccent,
        ),
        modifier = modifier.fillMaxWidth(),
    )
}

/** Pill chip. Selected = filled olive; unselected = bordered cream. */
@Composable
fun KasaChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val bg = if (selected) GreenPrimary else CreamHi
    val fg = if (selected) Cream else Ink
    Surface(
        color = bg,
        contentColor = fg,
        shape = RoundedCornerShape(50),
        border = if (selected) null else androidx.compose.foundation.BorderStroke(1.dp, Line),
        modifier = Modifier.clip(RoundedCornerShape(50)).clickable { onClick() },
    ) {
        Text(
            label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp),
        )
    }
}

@Composable
fun ChipGroup(
    options: List<String>,
    selected: Set<String>,
    onToggle: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
    FlowRowSimple(modifier = modifier) {
        options.forEach { opt ->
            KasaChip(opt, selected.contains(opt)) { onToggle(opt) }
        }
    }
}

/** Minimal wrapping row used for chip clusters throughout KASA. */
@OptIn(androidx.compose.foundation.layout.ExperimentalLayoutApi::class)
@Composable
fun FlowRowSimple(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    androidx.compose.foundation.layout.FlowRow(
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp),
    ) { content() }
}

@Composable
fun LabeledSlider(
    label: String,
    value: Float,
    onValueChange: (Float) -> Unit,
    leftHint: String,
    rightHint: String,
) {
    Column(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.titleMedium, color = Ink)
        Slider(
            value = value,
            onValueChange = onValueChange,
            valueRange = 0f..100f,
            colors = SliderDefaults.colors(
                thumbColor = GreenPrimary,
                activeTrackColor = GreenPrimary,
                inactiveTrackColor = Line,
            ),
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(leftHint, style = MaterialTheme.typography.labelMedium, color = Muted)
            Text(rightHint, style = MaterialTheme.typography.labelMedium, color = Muted)
        }
    }
}

/** Circular compatibility badge, e.g. 92%. */
@Composable
fun CompatibilityRing(score: Int, modifier: Modifier = Modifier, size: Int = 56) {
    Box(
        modifier = modifier.size(size.dp).clip(CircleShape).background(GreenPrimary),
        contentAlignment = Alignment.Center,
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("$score%", color = Cream, fontWeight = FontWeight.Bold, fontSize = (size / 3.4f).sp)
            Text("match", color = Cream.copy(alpha = 0.8f), fontSize = (size / 7f).sp)
        }
    }
}

@Composable
fun VerifiedPill(text: String) {
    Surface(color = GreenPrimary.copy(alpha = 0.08f), shape = RoundedCornerShape(50)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
        ) {
            Text("✓ ", color = LikeGreen, fontWeight = FontWeight.Bold)
            Text(text, style = MaterialTheme.typography.labelMedium, color = GreenAccent)
        }
    }
}

/**
 * The signature "Compatibility Fingerprint": a radar over 6 lifestyle axes.
 * [axes] = list of (label, value 0f..1f).
 */
@Composable
fun FingerprintRadar(
    axes: List<Pair<String, Float>>,
    modifier: Modifier = Modifier,
    stroke: Color = GreenPrimary,
    fill: Color = GreenPrimary.copy(alpha = 0.16f),
) {
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(modifier = Modifier.fillMaxSize().padding(28.dp)) {
            val n = axes.size
            if (n < 3) return@Canvas
            val cx = size.width / 2f
            val cy = size.height / 2f
            val radius = min(cx, cy)
            val step = (2.0 * Math.PI / n)
            val start = -Math.PI / 2.0

            fun pointAt(i: Int, r: Float): Offset {
                val a = start + i * step
                return Offset((cx + r * cos(a)).toFloat(), (cy + r * sin(a)).toFloat())
            }

            // concentric grid rings
            for (ring in 1..4) {
                val r = radius * ring / 4f
                val p = Path()
                for (i in 0 until n) {
                    val pt = pointAt(i, r)
                    if (i == 0) p.moveTo(pt.x, pt.y) else p.lineTo(pt.x, pt.y)
                }
                p.close()
                drawPath(p, color = Line, style = Stroke(width = 1f))
            }
            // spokes
            for (i in 0 until n) {
                drawLine(Line, Offset(cx, cy), pointAt(i, radius), strokeWidth = 1f)
            }
            // data polygon
            val data = Path()
            axes.forEachIndexed { i, (_, v) ->
                val pt = pointAt(i, radius * v.coerceIn(0f, 1f))
                if (i == 0) data.moveTo(pt.x, pt.y) else data.lineTo(pt.x, pt.y)
            }
            data.close()
            drawPath(data, color = fill)
            drawPath(data, color = stroke, style = Stroke(width = 2.5f))
        }
    }
}

@Composable
fun ErrorBanner(message: String?, modifier: Modifier = Modifier) {
    AnimatedVisibility(visible = message != null) {
        Surface(
            color = SkipClay.copy(alpha = 0.1f),
            shape = RoundedCornerShape(12.dp),
            modifier = modifier.fillMaxWidth(),
        ) {
            Text(
                message.orEmpty(),
                color = SkipClay,
                textAlign = TextAlign.Start,
                style = MaterialTheme.typography.bodyMedium,
                modifier = Modifier.padding(14.dp),
            )
        }
    }
}

@Composable
fun FullScreenLoader() {
    Box(Modifier.fillMaxSize().background(Cream), contentAlignment = Alignment.Center) {
        CircularProgressIndicator(color = GreenPrimary)
    }
}

/* ------------------- Compatibility fingerprint mapping ------------------- */

/**
 * Maps lifestyle fields onto the six signature KASA axes
 * (Sleep, Diet, Noise, Clean, Social, Guests), each normalised to 0f..1f.
 * Unknown inputs fall back to a neutral 0.5 so the radar still renders.
 */
fun fingerprintAxes(
    sleepTime: String?,
    foodPref: String?,
    noise: Int?,
    cleanliness: Int?,
    social: String?,
    guestFrequency: String?,
): List<Pair<String, Float>> = listOf(
    "Sleep" to morningness(sleepTime),
    "Diet" to dietScale(foodPref),
    "Noise" to ((noise ?: 50) / 100f).coerceIn(0f, 1f),
    "Clean" to ((cleanliness ?: 50) / 100f).coerceIn(0f, 1f),
    "Social" to socialScale(social),
    "Guests" to guestScale(guestFrequency),
)

private fun morningness(time: String?): Float {
    val hour = time?.substringBefore(":")?.toIntOrNull() ?: return 0.5f
    val effective = if (hour < 12) hour + 24 else hour // 0–2am wrap past midnight
    return ((26f - effective) / 5f).coerceIn(0f, 1f)
}

private fun dietScale(food: String?): Float = when (food?.lowercase()) {
    "vegan" -> 1.0f
    "jain" -> 0.92f
    "vegetarian" -> 0.85f
    "eggetarian" -> 0.6f
    "non-veg", "non-vegetarian" -> 0.3f
    else -> 0.5f
}

private fun socialScale(s: String?): Float = when (s?.lowercase()) {
    "introvert" -> 0.25f
    "ambivert" -> 0.55f
    "extrovert" -> 0.9f
    else -> 0.5f
}

private fun guestScale(g: String?): Float = when (g?.lowercase()) {
    "rarely" -> 0.2f
    "occasionally" -> 0.55f
    "frequently" -> 0.9f
    else -> 0.5f
}
