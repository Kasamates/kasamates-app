package com.kasamates.app.core.network.dto


/* ----------------------------- Auth ----------------------------- */

data class RegisterRequest(
    val email: String,
    val password: String,
    val name: String,
    val phone: String? = null,
)

data class LoginRequest(val email: String, val password: String)

data class TokenResponse(
    val access_token: String,
    val refresh_token: String,
    val token_type: String = "bearer",
    val user_id: Int,
    val is_email_verified: Boolean,
    val is_phone_verified: Boolean,
    val onboarding_step: Int,
)

data class SendOtpRequest(val contact: String, val otp_type: String)

data class VerifyOtpRequest(val otp_code: String, val otp_type: String)

data class RefreshRequest(val refresh_token: String)

data class MessageResponse(val message: String? = null, val next_step: Int? = null)

/* ----------------------------- User ----------------------------- */

data class UserOut(
    val id: Int,
    val email: String,
    val phone: String? = null,
    val name: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val profile_photo_url: String? = null,
    val is_email_verified: Boolean = false,
    val is_phone_verified: Boolean = false,
    val is_profile_complete: Boolean = false,
    val onboarding_step: Int = 0,
    val plan: String = "free",
    val is_verified_badge: Boolean = false,
    val is_admin: Boolean = false,
    val messages_sent: Int = 0,
    val created_at: String? = null,
)

data class UpdateUserRequest(
    val name: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val phone: String? = null,
    val fcm_token: String? = null,
)

data class PhotoUploadResponse(val url: String, val message: String? = null)

/* -------------------------- Onboarding -------------------------- */

data class StepBasicInfo(
    val name: String, val age: Int, val gender: String,
    val occupation: String? = null, val listing_type: String? = null,
)

data class StepLifestyle(
    val wake_time: String, val sleep_time: String,
    val noise_tolerance: Int, val cooking_frequency: String,
)

data class StepCleanliness(
    val cleanliness_level: Int, val cleaning_schedule: String,
    val organization_style: List<String> = emptyList(),
)

data class StepSocial(
    val social_energy: String, val guest_frequency: String, val alone_time_importance: Int,
)

data class StepValues(
    val work_life_balance: String,
    val important_values: List<String> = emptyList(),
    val conflict_resolution: String,
)

data class StepPreferences(
    val pets: String, val smoking: String, val drinking: String,
    val budget_min: Int, val budget_max: Int,
    val location: String, val location_preferences: List<String> = emptyList(),
    val food_pref: String? = null, val bio: String? = null,
)

data class ProfileOut(
    val id: Int = 0,
    val user_id: Int = 0,
    val listing_type: String? = null,
    val location: String? = null,
    val location_preferences: List<String>? = emptyList(),
    val budget_min: Int? = 0,
    val budget_max: Int? = 0,
    val occupation: String? = null,
    val wake_time: String? = null,
    val sleep_time: String? = null,
    val noise_tolerance: Int? = 50,
    val cooking_frequency: String? = null,
    val cleanliness_level: Int? = 50,
    val cleaning_schedule: String? = null,
    val organization_style: List<String>? = emptyList(),
    val social_energy: String? = null,
    val guest_frequency: String? = null,
    val alone_time_importance: Int? = 50,
    val work_life_balance: String? = null,
    val important_values: List<String>? = emptyList(),
    val conflict_resolution: String? = null,
    val pets: String? = null,
    val smoking: String? = null,
    val drinking: String? = null,
    val food_pref: String? = null,
    val vehicle: String? = null,
    val personality_tags: List<String>? = emptyList(),
    val vibes: List<String>? = emptyList(),
    val bio: String? = null,
    val sleep_schedule: String? = null,
    val guest_policy: String? = null,
)

/* ---------------------- Browse / Matching ----------------------- */

data class CardProfile(
    val budget_min: Int? = null,
    val budget_max: Int? = null,
    val cleanliness_level: Int? = null,
    val smoking: String? = null,
    val drinking: String? = null,
    val sleep_time: String? = null,
    val sleep_schedule: String? = null,
    val wake_time: String? = null,
    val food_pref: String? = null,
    val vibes: List<String>? = emptyList(),
    val personality_tags: List<String>? = emptyList(),
    val social_energy: String? = null,
    val pets: String? = null,
    val noise_tolerance: Int? = null,
    val location: String? = null,
    val occupation: String? = null,
    val bio: String? = null,
)

data class MatchCard(
    val user_id: Int,
    val source: String = "app",
    val name: String? = null,
    val age: Int? = null,
    val gender: String? = null,
    val profile_photo_url: String? = null,
    val plan: String = "free",
    val is_verified_badge: Boolean = false,
    val profile: CardProfile? = null,
    val compatibility_score: Int = 0,
    val ai_blurb: String? = null,
    val platform_note: String? = null,
)

data class BrowseResponse(
    val total: Int = 0,
    val page: Int = 1,
    val page_size: Int = 20,
    val app_users_count: Int = 0,
    val web_users_count: Int = 0,
    val results: List<MatchCard> = emptyList(),
)

/* ----------------------------- Chat ----------------------------- */

data class SendMessageRequest(val receiver_id: Int, val content: String)

data class MessageOut(
    val id: Int,
    val sender_id: Int,
    val receiver_id: Int,
    val content: String,
    val is_read: Boolean = false,
    val created_at: String? = null,
    val sender_name: String? = null,
)

data class ConversationOut(
    val other_user_id: Int,
    val other_user_name: String? = null,
    val other_user_photo: String? = null,
    val last_message: String? = null,
    val last_time: String? = null,
    val unread_count: Int = 0,
)

/* ------------------------------ AI ------------------------------ */

data class BlurbResponse(val blurb: String? = null)

data class ReportResponse(val report: String? = null)

data class OnboardingStatus(
    val onboarding_step: Int = 0,
    val is_email_verified: Boolean = false,
    val is_phone_verified: Boolean = false,
    val is_profile_complete: Boolean = false,
    val has_profile: Boolean = false,
)
