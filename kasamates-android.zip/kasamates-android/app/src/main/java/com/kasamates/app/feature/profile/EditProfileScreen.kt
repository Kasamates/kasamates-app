package com.kasamates.app.feature.profile

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.kasamates.app.core.di.kasaViewModel
import com.kasamates.app.feature.onboarding.OnbForm
import com.kasamates.app.ui.common.*
import com.kasamates.app.ui.theme.*

private val genders = listOf("Male", "Female", "Non-binary", "Prefer not to say")
private val social = listOf("Introvert", "Ambivert", "Extrovert")
private val smoking = listOf("Non-smoker", "Smoker", "Occasional", "Outside only")
private val drinking = listOf("Non-drinker", "Social drinker", "Regular")
private val food = listOf("Vegetarian", "Vegan", "Non-veg", "Eggetarian", "Jain")
private val listing = listOf("Seeking a room", "Offering a room", "Seeking a flatmate")
private val areas = listOf("Gurugram", "Noida", "Faridabad", "South Delhi", "Dwarka", "Greater Noida")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EditProfileScreen(onDone: () -> Unit) {
    val vm = kasaViewModel<ProfileViewModel>()
    val ui by vm.ui.collectAsStateWithLifecycle()

    var form by remember { mutableStateOf<OnbForm?>(null) }
    LaunchedEffect(ui.user, ui.profile) {
        if (form == null && (ui.user != null || ui.profile != null)) form = vm.toForm()
    }

    Scaffold(
        containerColor = Cream,
        topBar = {
            TopAppBar(
                title = { Text("Edit profile", fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold, color = Ink) },
                navigationIcon = { TextButton(onClick = onDone) { Text("←", fontSize = 22.sp, color = GreenAccent) } },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CreamSurface, titleContentColor = Ink),
            )
        },
    ) { pad ->
        val f = form
        if (f == null) {
            Box(Modifier.fillMaxSize().padding(pad), Alignment.Center) { CircularProgressIndicator(color = GreenPrimary) }
            return@Scaffold
        }
        Column(
            Modifier.fillMaxSize().padding(pad).verticalScroll(rememberScrollState()).padding(horizontal = 24.dp),
        ) {
            Spacer(Modifier.height(8.dp))
            KasaField(f.name, { form = f.copy(name = it) }, "Full name")
            Spacer(Modifier.height(12.dp))
            KasaField(f.age, { form = f.copy(age = it.filter(Char::isDigit).take(2)) }, "Age", keyboardType = KeyboardType.Number)
            Spacer(Modifier.height(16.dp))

            Label("Gender")
            Single(genders, f.gender) { form = f.copy(gender = it) }
            Spacer(Modifier.height(16.dp))
            KasaField(f.occupation, { form = f.copy(occupation = it) }, "Occupation")
            Spacer(Modifier.height(16.dp))

            Label("Looking to")
            Single(listing, f.listingType) { form = f.copy(listingType = it) }
            Spacer(Modifier.height(16.dp))

            Label("Monthly budget (₹)")
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.weight(1f)) { KasaField(f.budgetMin, { form = f.copy(budgetMin = it.filter(Char::isDigit).take(6)) }, "Min", keyboardType = KeyboardType.Number) }
                Box(Modifier.weight(1f)) { KasaField(f.budgetMax, { form = f.copy(budgetMax = it.filter(Char::isDigit).take(6)) }, "Max", keyboardType = KeyboardType.Number) }
            }
            Spacer(Modifier.height(16.dp))
            KasaField(f.location, { form = f.copy(location = it) }, "Primary area")
            Spacer(Modifier.height(12.dp))
            Label("Open to areas")
            ChipGroup(areas, f.locationPrefs, { form = f.copy(locationPrefs = f.locationPrefs.toggle(it)) })
            Spacer(Modifier.height(16.dp))

            Label("Social energy")
            Single(social, f.socialEnergy) { form = f.copy(socialEnergy = it) }
            Spacer(Modifier.height(16.dp))
            LabeledSlider("Tidiness level", f.cleanliness, { form = f.copy(cleanliness = it) }, "Relaxed", "Spotless")
            Spacer(Modifier.height(16.dp))

            Label("Smoking")
            Single(smoking, f.smoking) { form = f.copy(smoking = it) }
            Spacer(Modifier.height(16.dp))
            Label("Drinking")
            Single(drinking, f.drinking) { form = f.copy(drinking = it) }
            Spacer(Modifier.height(16.dp))
            Label("Food preference")
            Single(food, f.foodPref) { form = f.copy(foodPref = it) }
            Spacer(Modifier.height(16.dp))

            KasaField(f.bio, { form = f.copy(bio = it) }, "Short bio", singleLine = false)
            Spacer(Modifier.height(16.dp))
            ErrorBanner(ui.error)
            Spacer(Modifier.height(8.dp))
            PrimaryButton("Save changes", loading = ui.saving, onClick = { vm.saveAll(f, onDone) })
            Spacer(Modifier.height(32.dp))
        }
    }
}

@Composable
private fun Label(text: String) =
    Text(text, style = MaterialTheme.typography.titleSmall, color = Ink, modifier = Modifier.padding(bottom = 8.dp))

@Composable
private fun Single(options: List<String>, selected: String, onSelect: (String) -> Unit) {
    FlowRowSimple { options.forEach { KasaChip(it, selected == it) { onSelect(it) } } }
}

private fun Set<String>.toggle(v: String): Set<String> = if (contains(v)) this - v else this + v
