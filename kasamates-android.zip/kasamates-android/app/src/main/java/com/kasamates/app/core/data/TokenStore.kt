package com.kasamates.app.core.data

import android.content.Context
import com.kasamates.app.core.network.dto.TokenResponse

/**
 * Synchronous token storage backed by SharedPreferences so the OkHttp
 * interceptor/authenticator can read the current access token off any thread.
 * For production, swap this for EncryptedSharedPreferences.
 */
class TokenStore(context: Context) {
    private val prefs = context.getSharedPreferences("kasa_session", Context.MODE_PRIVATE)

    var accessToken: String?
        get() = prefs.getString(KEY_ACCESS, null)
        set(value) { prefs.edit().putString(KEY_ACCESS, value).apply() }

    var refreshToken: String?
        get() = prefs.getString(KEY_REFRESH, null)
        set(value) { prefs.edit().putString(KEY_REFRESH, value).apply() }

    val userId: Int get() = prefs.getInt(KEY_UID, -1)
    val onboardingStep: Int get() = prefs.getInt(KEY_STEP, 0)
    val emailVerified: Boolean get() = prefs.getBoolean(KEY_EMAIL_V, false)
    val phoneVerified: Boolean get() = prefs.getBoolean(KEY_PHONE_V, false)

    val isLoggedIn: Boolean get() = !accessToken.isNullOrBlank()

    fun saveTokens(t: TokenResponse) {
        prefs.edit()
            .putString(KEY_ACCESS, t.access_token)
            .putString(KEY_REFRESH, t.refresh_token)
            .putInt(KEY_UID, t.user_id)
            .putInt(KEY_STEP, t.onboarding_step)
            .putBoolean(KEY_EMAIL_V, t.is_email_verified)
            .putBoolean(KEY_PHONE_V, t.is_phone_verified)
            .apply()
    }

    fun updateAccess(token: String) { accessToken = token }

    fun clear() { prefs.edit().clear().apply() }

    private companion object {
        const val KEY_ACCESS = "access"
        const val KEY_REFRESH = "refresh"
        const val KEY_UID = "uid"
        const val KEY_STEP = "step"
        const val KEY_EMAIL_V = "email_v"
        const val KEY_PHONE_V = "phone_v"
    }
}
