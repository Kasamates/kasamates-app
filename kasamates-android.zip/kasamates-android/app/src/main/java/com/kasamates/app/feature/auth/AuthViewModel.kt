package com.kasamates.app.feature.auth

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.ui.nav.Routes
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class AuthUiState(
    val loading: Boolean = false,
    val error: String? = null,
    val info: String? = null,
)

/**
 * Handles login + registration against the FastAPI backend (email/password),
 * and decides where a returning user should land on launch.
 */
class AuthViewModel(private val repo: KasaRepository) : ViewModel() {

    private val _ui = MutableStateFlow(AuthUiState())
    val ui = _ui.asStateFlow()

    /** Email used for the most recent auth attempt (handy to pre-fill the OTP screen). */
    var lastEmail: String = ""
        private set

    /** Decide the start screen for an already-installed session. */
    suspend fun resolveStartDestination(): String {
        if (!repo.isLoggedIn) return Routes.AUTH
        val me = repo.me().getOrNull() ?: return Routes.AUTH
        return when {
            !me.is_email_verified -> Routes.OTP
            me.onboarding_step < 6 -> Routes.ONBOARDING
            else -> Routes.HOME
        }
    }

    fun login(email: String, password: String, onResult: (needsOtp: Boolean) -> Unit) {
        if (!validate(email, password)) return
        lastEmail = email.trim()
        launch {
            repo.login(email.trim(), password).fold(
                onSuccess = { t ->
                    _ui.update { it.copy(loading = false) }
                    onResult(!t.is_email_verified)
                },
                onFailure = { e -> fail(e.message) },
            )
        }
    }

    fun register(
        name: String,
        email: String,
        password: String,
        phone: String?,
        onResult: () -> Unit,
    ) {
        if (name.isBlank()) { _ui.update { it.copy(error = "Please enter your name.") }; return }
        if (!validate(email, password)) return
        lastEmail = email.trim()
        launch {
            repo.register(name.trim(), email.trim(), password, phone?.trim()?.ifBlank { null }).fold(
                onSuccess = {
                    // Kick off email verification immediately.
                    repo.sendOtp("email", email.trim())
                    _ui.update { it.copy(loading = false) }
                    onResult()
                },
                onFailure = { e -> fail(e.message) },
            )
        }
    }

    fun verifyEmailOtp(code: String, onVerified: () -> Unit) {
        if (code.length < 4) { _ui.update { it.copy(error = "Enter the code we sent you.") }; return }
        launch {
            repo.verifyOtp("email", code.trim()).fold(
                onSuccess = { _ui.update { it.copy(loading = false) }; onVerified() },
                onFailure = { e -> fail(e.message) },
            )
        }
    }

    fun resendEmailOtp() {
        val email = lastEmail
        if (email.isBlank()) { _ui.update { it.copy(error = "Missing email — please log in again.") }; return }
        launch {
            repo.sendOtp("email", email).fold(
                onSuccess = { _ui.update { it.copy(loading = false, info = "Code sent to $email.") } },
                onFailure = { e -> fail(e.message) },
            )
        }
    }

    fun clearError() = _ui.update { it.copy(error = null) }

    private fun validate(email: String, password: String): Boolean {
        if (!email.contains("@") || email.length < 5) {
            _ui.update { it.copy(error = "Enter a valid email address.") }; return false
        }
        if (password.length < 6) {
            _ui.update { it.copy(error = "Password must be at least 6 characters.") }; return false
        }
        return true
    }

    private inline fun launch(crossinline block: suspend () -> Unit) {
        _ui.update { it.copy(loading = true, error = null, info = null) }
        viewModelScope.launch { block() }
    }

    private fun fail(message: String?) =
        _ui.update { it.copy(loading = false, error = message ?: "Something went wrong.") }
}
