package com.kasamates.app.feature.chat

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.kasamates.app.core.data.KasaRepository
import com.kasamates.app.core.network.dto.MessageOut
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class ChatUi(
    val loading: Boolean = true,
    val error: String? = null,
    val sending: Boolean = false,
    val messages: List<MessageOut> = emptyList(),
)

class ChatViewModel(private val repo: KasaRepository) : ViewModel() {

    private val _ui = MutableStateFlow(ChatUi())
    val ui = _ui.asStateFlow()

    val myId: Int get() = repo.currentUserId
    private var otherId: Int = -1

    fun start(otherUserId: Int) {
        if (otherId == otherUserId && _ui.value.messages.isNotEmpty()) return
        otherId = otherUserId
        _ui.update { it.copy(loading = true, error = null) }
        load(initial = true)
    }

    /** Silent refresh used by the polling loop. */
    fun refresh() = load(initial = false)

    private fun load(initial: Boolean) {
        if (otherId < 0) return
        viewModelScope.launch {
            repo.conversation(otherId).fold(
                onSuccess = { list -> _ui.update { it.copy(loading = false, messages = list) } },
                onFailure = { e -> if (initial) _ui.update { it.copy(loading = false, error = e.message) } },
            )
        }
    }

    fun send(text: String) {
        val body = text.trim()
        if (body.isEmpty() || otherId < 0) return
        _ui.update { it.copy(sending = true) }
        viewModelScope.launch {
            repo.sendMessage(otherId, body).fold(
                onSuccess = { msg ->
                    _ui.update { it.copy(sending = false, messages = it.messages + msg) }
                },
                onFailure = { e -> _ui.update { it.copy(sending = false, error = e.message) } },
            )
        }
    }

    fun clearError() = _ui.update { it.copy(error = null) }
}
