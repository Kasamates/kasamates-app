# Moshi / Retrofit
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.kasamates.app.core.network.dto.** { *; }
-keep class kotlin.Metadata { *; }
