# Kasamates (KASA) — Android Client

A native Android client (Kotlin + Jetpack Compose) for **Kasamates**, the broker-free
flatmate-matching app for Delhi-NCR. This project is wired to the project's FastAPI
backend ([Kasamates-App-Backend](https://github.com/Kasamates/Kasamates-App-Backend)).

The flow mirrors the product: **register → verify email OTP → 6-step onboarding →
swipe-to-discover → match → chat**, plus a browse grid and a profile built around the
signature **Compatibility Fingerprint** radar.

---

## 1. Run the backend (port 8001)

```bash
git clone https://github.com/Kasamates/Kasamates-App-Backend
cd Kasamates-App-Backend
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
cp .env.example .env          # set SECRET_KEY, GROQ_API_KEY, etc.
uvicorn app.main:app --host 0.0.0.0 --port 8001 --reload
```

The API is served under `/api/v1`; uploaded photos under `/uploads`. The client expects
both of these paths and prefixes relative photo URLs automatically.

## 2. Point the app at your backend

`BASE_URL` is injected per build type via `buildConfigField` in `app/build.gradle.kts`:

| Build | Default `BASE_URL` | Use when |
|-------|--------------------|----------|
| debug | `http://10.0.2.2:8001/` | Android **emulator** → host machine |
| release | `https://app-api.kasamates.in/` | Production app backend |

- **Physical device on the same Wi-Fi:** change the debug value to your machine's LAN IP,
  e.g. `http://192.168.1.20:8001/`, and add that host to
  `app/src/main/res/xml/network_security_config.xml` (cleartext is currently allowed only
  for `10.0.2.2` and `localhost`).
- **Production:** deploy the FastAPI service behind HTTPS and set the release `BASE_URL`
  to its host. No cleartext exception is needed for HTTPS.

## 3. Open in Android Studio

Open the project root, let Gradle sync, then Run on an emulator (API 26+).
Toolchain targets: AGP 8.6.1 · Kotlin 2.0.20 · Gradle 8.9 · compileSdk 35 · JDK 17.

> This project was assembled outside Android Studio, so a first sync may ask you to nudge
> a plugin/library version to match your installed SDK — accept the suggested alignment if
> prompted. No source changes should be required.

---

## Architecture

```
ui/theme            Palette, type scale, Material3 theme
ui/common           Reusable Compose pieces incl. FingerprintRadar
core/network        Retrofit API, Moshi DTOs, auth + refresh interceptors
core/data           Repository (Result-wrapped) + token storage
core/di             Tiny service locator + ViewModel factory
feature/*           auth · onboarding · browse · matches · chat · profile · home
```

State is `ViewModel` + `StateFlow`, collected with `collectAsStateWithLifecycle`.
Networking is Retrofit + Moshi (reflection adapter, no codegen) with an OkHttp
`Authenticator` that transparently refreshes the access token on a 401.

---

## Mapping to the backend contract

| App action | Endpoint |
|------------|----------|
| Register / Sign in | `POST /auth/register`, `POST /auth/login` |
| Email OTP | `POST /auth/send-otp`, `POST /auth/verify-otp` |
| Onboarding steps 1–6 | `POST /onboarding/step/{n-...}` (upsert) |
| Discover / Browse | `GET /matches/browse` |
| Like / Skip / Super-like | `POST /matches/interaction` |
| Conversations / Chat | `GET /messages/conversations`, `GET /messages/conversation/{id}`, `POST /messages/send` |
| Profile | `GET /users/me`, `GET /onboarding/profile`, `POST /users/me/photo` |

---

## Assumptions & deliberate deviations

These are called out so they're easy to reconcile with the design and backend:

1. **Auth is email + password.** The skeleton video shows a phone-first/OTP screen, but the
   backend's primary credential is email + password with an **email** OTP verification step.
   The client follows the backend; phone verification is surfaced as a later step.
2. **"Continue with Google" is a placeholder.** There is no Google-OAuth endpoint in the
   backend, so the button is present (to match the design) but disabled with a "coming soon"
   note rather than faking a flow.
3. **Editing a profile re-submits onboarding steps.** The backend has no generic
   lifestyle/profile `PUT`; the step endpoints are upserts, so *Edit profile* re-POSTs the
   relevant `onboarding/step/*` calls. This is intentional, not a workaround left unfinished.
4. **"It's a match" is detected heuristically.** `POST /matches/interaction` returns a
   `{message, next_step}` envelope; a match is inferred when the message indicates one. If the
   backend later returns a structured `is_match` flag, swap the check in `BrowseViewModel`.
5. **Activity tab is an honest premium screen.** The video showed an activity feed behind a
   paywall, but no feed endpoint exists. Rather than fabricate data, the tab presents the real
   free-tier limit (5 messages) and the Plus upsell; billing is not wired.

---

## Interactive prototype

`kasamates-prototype.html` (delivered alongside this project) is a single self-contained
file reproducing the full KASA experience — auth, OTP, onboarding, swipe discovery, match,
browse, chat, and the Compatibility Fingerprint radar — using the same sampled palette.
Open it in any browser to click through the design; it runs on in-memory mock data and needs
no backend.
